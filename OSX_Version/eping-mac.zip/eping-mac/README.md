# eping for macOS

Web GUI version of eping. Start `eping.app`: eping runs in the background, the web GUI opens in the browser as soon as
eping answers (http://127.0.0.1:8080) and a small window controls it (same as the Windows version):
Status, web port, Start / Stop / Restart, Open web GUI, Console log, Exit and an Update
button that appears when GitHub has a newer version.

## Requirements

- macOS 10.13 or newer (Apple Silicon and Intel)
- Python 3.11 is included (`python-aarch64`, `python-x86_64`); without it `python3` 3.6+ from the system is used
- `fping` (universal binary, included): used from this folder first, otherwise from Homebrew

## Files

- `python-aarch64`, `python-x86_64` Python 3.11 (python-build-standalone), `fping` fping 5.5 (arm64 + x86_64), `eping.app` launcher, `eping.py` monitor (web GUI mode), `epinga.py` log analyser
- `eping-args.txt` optional, one line of options, e.g. `-f hosts.txt -w 2`
- Hosts files, logs and `eping-console.log` are stored in this folder.

## Update

The launcher checks GitHub (`eversions`) at start and every 6 hours. If `eping.py` / `epinga.py`
are newer, the Update button replaces them; if `eping-mac` is newer, the whole package.
The web port is stored as `opt: -port N` in the hosts file.

## First start

Downloaded files are quarantined by macOS. The installer removes this flag; for a manual
download run once: `xattr -dr com.apple.quarantine <eping folder>`.
Do not run eping.app directly from the Downloads zip preview.

## Window

Below the buttons: checkboxes *Disable autostart* and *Disable logging* (`-dl`), *Disable file* (`-df`, no hosts file), a *CLI options* field (stored in `eping-args.txt`) and a *Check updates* button. Settings (`eping-launcher.cfg`) apply at Start / Restart.
