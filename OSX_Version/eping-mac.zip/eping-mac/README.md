# eping for macOS

Web GUI version of eping. Start `eping.app`: eping runs in the background, the web GUI
opens in the browser (http://127.0.0.1:8080) and a small dialog controls it
(Open web GUI / Start / More... / Quit eping).

## Requirements

- macOS 10.13 or newer (Apple Silicon and Intel)
- Python 3.11 is included (`python-aarch64`, `python-x86_64`); without it `python3` 3.6+ from the system is used
- `fping` (universal binary, included): used from this folder first, otherwise from Homebrew

## Files

- `python-aarch64`, `python-x86_64` Python 3.11 (python-build-standalone), `fping` fping 5.5 (arm64 + x86_64), `eping.app` launcher, `eping.py` monitor (web GUI mode), `epinga.py` log analyser
- `eping-args.txt` optional, one line of options, e.g. `-f hosts.txt -w 2`
- Hosts files, logs and `eping-console.log` are stored in this folder.

## Dialog

- More...: Restart, Stop, Change port (stored as `opt: -port N` in the hosts file),
  Console log, Check for updates, Update now.
- The launcher checks GitHub (`eversions`) at start and every 6 hours.

## First start

Downloaded files are quarantined by macOS. The installer removes this flag; for a manual
download run once: `xattr -dr com.apple.quarantine <eping folder>`.
Do not run eping.app directly from the Downloads zip preview.
