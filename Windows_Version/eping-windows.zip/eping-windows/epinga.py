#!/usr/bin/env python3

# - - - - - - - - - - - - - - - - - - - - - - - -
# epinga.py by ewald@jeitler.cc 2024 https://www.jeitler.cc
# Large-file-capable analyser for eping.py CSV logfiles
# Streams the CSV row-by-row – RAM usage stays flat even for GB-sized logs
# - - - - - - - - - - - - - - - - - - - - - - - -

VERSION = '2.47'
version = VERSION   # legacy alias

import re
import os
import csv
import sys
import json
import time
import signal
import argparse
import datetime
import ipaddress
import html as html_lib

import io
import zipfile
import urllib.request

# ── colour helpers ────────────────────────────────────────────────────────────
CRED    = '\033[91m'
CGREEN  = '\033[92m'
CORANGE = '\033[33m'
CCYAN   = '\033[96m'
CBOLD   = '\033[1m'
CDIM    = '\033[2m'
CEND    = '\033[0m'

W = 100   # output width

def col(text, colour): return colour + text + CEND
def hr(ch='─'): print(ch * W)
def header_line(title, ch='─'):
    t = f' {title} '
    print(t.center(W, ch))

# ── signal / error helpers ────────────────────────────────────────────────────
def sigint_handler(sig, frame):
    print(f'\n{col("Interrupted.", CORANGE)}  epinga.py v{VERSION}  – www.jeitler.cc\n')
    sys.exit(0)

def die(msg):
    print(f'\n {col("ERROR:", CRED)} {msg}\n')
    sys.exit(1)

# ── regex ─────────────────────────────────────────────────────────────────────
ip_re   = re.compile(r'^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}'
                     r'([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$')


def version_tuple(v):
    """'2.27' -> (2, 27): numeric version compare ('2.9' > '2.26' is True as strings)."""
    out = []
    for part in str(v or '').split('.'):
        try:
            out.append(int(part))
        except ValueError:
            out.append(0)
    return tuple(out)

def sort_hosts(hosts):
    ips, fqdns = [], []
    for h in hosts:
        (ips if ip_re.match(h) else fqdns).append(h)
    ips.sort(key=lambda x: int(ipaddress.ip_address(x)))
    fqdns.sort()
    return ips + fqdns

# ── version check ─────────────────────────────────────────────────────────────
def check_version_online(url, tool_name, timeout=2.0):
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            for line in r.read().decode('utf-8', 'replace').splitlines():
                parts = line.split()
                if len(parts) >= 2 and parts[0] == tool_name:
                    return parts[1]
    except Exception:
        pass
    return None

# ── timestamp parsing ─────────────────────────────────────────────────────────
TS_FMT = '%Y-%m-%d %H:%M:%S'

_TS_CACHE = {}      # rows of one second share a timestamp - strptime is the costliest call per row

def parse_ts(s):
    r = _TS_CACHE.get(s)
    if r is not None:
        return r
    try:
        r = datetime.datetime.strptime(s.strip(), TS_FMT)
    except ValueError:
        return None
    if len(_TS_CACHE) > 50000:
        _TS_CACHE.clear()
    _TS_CACHE[s] = r
    return r

# ── byte-tracking file wrapper (tell() fails with next(), so we count ourselves) ──
class _ByteTracker:
    """Wraps a *binary* file: counts raw bytes per line and decodes once, so the
    progress bar needs no tell() and no re-encode of every line."""
    def __init__(self, fh, encoding='utf-8'):
        self._fh       = fh
        self._enc      = encoding
        self.bytes_read = 0

    def readline(self):
        raw = self._fh.readline()
        self.bytes_read += len(raw)
        return raw.decode(self._enc, errors='replace')

    def __iter__(self):
        return self

    def __next__(self):
        line = self.readline()
        if line == '':
            raise StopIteration
        return line

    def __getattr__(self, name):        # proxy everything else (fieldnames etc.)
        return getattr(self._fh, name)


# ── progress bar (bytes) ──────────────────────────────────────────────────────
def fmt_bytes(n):
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n < 1024:
            return f'{n:.1f} {unit}'
        n /= 1024
    return f'{n:.1f} TB'

# --progress-file: machine-readable progress for eping.py's GENERATE REPORT (web gui)
_PROG = {'file': '', 'pass': 1, 'passes': 1, 't0': 0.0, 'last': 0.0, 'phase': 'analysing'}

def prog_write(done=0, total=0, phase=None, force=False):
    """Write {pct, eta, phase, pass, passes} as JSON (atomically, at most every 0.4 s). pct is
    over all passes (the main analysis plus one per source for the report's source switch),
    eta (seconds) is extrapolated from the elapsed time and only given once it is meaningful."""
    f = _PROG['file']
    if not f:
        return
    now = time.time()
    if not force and now - _PROG['last'] < 0.4:
        return
    _PROG['last'] = now
    if phase:
        _PROG['phase'] = phase
    frac    = min(1.0, done / total) if total > 0 else 0.0
    overall = ((_PROG['pass'] - 1) + frac) / _PROG['passes']
    el      = now - _PROG['t0']
    eta     = int(round(el * (1 - overall) / overall)) if (overall >= 0.02 and el >= 2) else None
    try:
        with open(f + '.tmp', 'w', encoding='utf-8') as fh:
            json.dump({'pct': round(overall * 100, 1), 'eta': eta, 'phase': _PROG['phase'],
                       'pass': _PROG['pass'], 'passes': _PROG['passes']}, fh)
        os.replace(f + '.tmp', f)
    except OSError:
        pass

class Progress:
    def __init__(self, total_bytes, width=40):
        self.total   = total_bytes
        self.width   = width
        self.last_pct = -1

    def update(self, done_bytes):
        if self.total <= 0:
            return
        pct = int(done_bytes * 100 / self.total)
        if pct == self.last_pct:
            return
        self.last_pct = pct
        filled = int(self.width * pct / 100)
        bar = '█' * filled + '░' * (self.width - filled)
        print(f'\r  [{bar}] {pct:3d}%  {fmt_bytes(done_bytes)}/{fmt_bytes(self.total)} ',
              end='', flush=True)

    def done(self):
        if self.total > 0:
            print()   # newline after progress bar

# ── per-host data class ───────────────────────────────────────────────────────
class HostStats:
    __slots__ = ('first_ts', 'last_ts', 'current_state', 'prev_ts',
                 'rtt_min', 'rtt_max', 'rtt_sum', 'rtt_cnt',
                 'time_up', 'time_down', 'time_nodns',
                 'changes', 'no_of_changes', 'ip', 'meta', 'gaps', 'gap_total')

    def __init__(self, ts, state, ip=''):
        self.first_ts      = ts
        self.last_ts       = ts
        self.prev_ts       = ts
        self.current_state = state
        self.rtt_min       = float('inf')
        self.rtt_max       = float('-inf')
        self.rtt_sum       = 0.0
        self.rtt_cnt       = 0
        self.time_up       = datetime.timedelta(0)
        self.time_down     = datetime.timedelta(0)
        self.time_nodns    = datetime.timedelta(0)
        self.changes       = []          # [(ts, prev_state, new_state)]
        self.no_of_changes = 0
        self.ip             = ip or ''   # last known pinged IP (from the CSV's IP column)
        self.meta           = None       # dict of inventory columns (see META_LOG_COLS), created on first value
        self.gaps           = []         # [(start, end)] periods of other sources (only with --source)
        self.gap_total      = datetime.timedelta(0)

    # ── feed one CSV row ──────────────────────────────────────────────────────
    def feed(self, ts, prev_state, cur_state, rtt_raw, no_of_changes_raw, ip_raw=''):
        # RTT
        try:
            rtt = float(rtt_raw)
            if rtt < self.rtt_min: self.rtt_min = rtt
            if rtt > self.rtt_max: self.rtt_max = rtt
            self.rtt_sum += rtt
            self.rtt_cnt += 1
        except (ValueError, TypeError):
            pass

        # state change
        if prev_state != cur_state:
            delta = ts - self.prev_ts if ts and self.prev_ts else datetime.timedelta(0)
            self._add_time(prev_state, delta)
            self.changes.append((ts, prev_state, cur_state))
            self.prev_ts       = ts
            self.current_state = cur_state

        self.last_ts = ts

        try:
            self.no_of_changes = int(no_of_changes_raw)
        except (ValueError, TypeError):
            pass

        if ip_raw:
            self.ip = ip_raw

    def new_segment(self, ts, state=''):
        # --source: rows of other sources lie between the last row and this one.
        # Close the open interval at the last own row, skip the gap.
        if ts and self.last_ts and ts > self.last_ts:
            self._add_time(self.current_state, self.last_ts - self.prev_ts)
            self.gaps.append((self.last_ts, ts))
            self.gap_total += ts - self.last_ts
            self.prev_ts = ts
            self.last_ts = ts
        if state:
            self.current_state = state    # a change during the gap is not ours

    def add_pauses(self, pauses):
        # STOP..START periods carry no data: draw them as gaps and do not count
        # them as time in any state. Call after finalise().
        if not self.first_ts or not self.last_ts:
            return
        for a, b in pauses:
            a = max(a, self.first_ts)
            b = min(b, self.last_ts)
            if b <= a:
                continue
            pieces = [(a, b)]
            for g0, g1 in self.gaps:           # source gaps are already excluded
                nx = []
                for p0, p1 in pieces:
                    if g1 <= p0 or g0 >= p1:
                        nx.append((p0, p1))
                        continue
                    if g0 > p0:
                        nx.append((p0, g0))
                    if g1 < p1:
                        nx.append((g1, p1))
                pieces = nx
            for p0, p1 in pieces:
                self._take_time(p0, p1)
            self.gaps.extend(pieces)
        self.gaps.sort()

    def _take_time(self, p0, p1):
        # remove [p0, p1] from the state time buckets, following the state changes
        state = self.changes[0][1] if self.changes else self.current_state
        cur = p0
        for cts, _pv, cv in self.changes:
            if cts <= p0:
                state = cv
                continue
            if cts >= p1:
                break
            self._add_time(state, -(cts - cur))
            cur, state = cts, cv
        self._add_time(state, -(p1 - cur))
        self.gap_total += p1 - p0
        zero = datetime.timedelta(0)
        self.time_up    = max(self.time_up, zero)
        self.time_down  = max(self.time_down, zero)
        self.time_nodns = max(self.time_nodns, zero)

    def _add_time(self, state, delta):
        if state == 'UP':
            self.time_up    += delta
        elif state == 'DOWN':
            self.time_down  += delta
        elif state == 'NO-DNS':
            self.time_nodns += delta

    # ── finalise: add last open interval ─────────────────────────────────────
    def finalise(self):
        if self.last_ts and self.prev_ts:
            delta = self.last_ts - self.prev_ts
            self._add_time(self.current_state, delta)

    # ── helpers ───────────────────────────────────────────────────────────────
    @property
    def has_rtt(self):
        return self.rtt_cnt > 0

    @property
    def rtt_avg(self):
        return round(self.rtt_sum / self.rtt_cnt, 2) if self.rtt_cnt else 0

    @property
    def total_span(self):
        if self.first_ts and self.last_ts:
            return self.last_ts - self.first_ts - self.gap_total
        return datetime.timedelta(0)

    @property
    def uptime_pct(self):
        span = self.total_span.total_seconds()
        if span <= 0:
            return 0.0
        pct = round(self.time_up.total_seconds() * 100 / span, 2)
        if pct > 99.99 and self.real_changes > 0:
            pct = 99.99          # a host with state changes is never shown as 100 % (even if rounding says so)
        return pct

    @property
    def real_changes(self):
        # Actual UP/DOWN/NO-DNS transitions observed in this log, derived from
        # PREVIOUS_STATE/CURRENT_STATE per row. Independent of the device-side
        # NO_OF_CHANGES counter, which eping.py's 'zero' command can reset
        # mid-log, making the raw counter unreliable for classification.
        return len(self.changes)


# inventory columns eping.py 3.62+ appends to each log row: report key -> log column
META_LOG_COLS = (('inv_name', 'INV_HOSTNAME'), ('serial', 'SERIAL_NUMBER'), ('model', 'MODEL'),
                 ('location', 'LOCATION'), ('sysloc', 'SYSLOCATION'), ('type', 'TYPE'),
                 ('comment', 'INV_COMMENT'))

# ── logfile access: plain *.csv or zipped *.csv.zip (one csv member) ──────────
def is_zip_log(path):
    return str(path).lower().endswith('.zip')


def log_base(path):
    """File name without .csv / .csv.zip - basis of the report names."""
    b = os.path.basename(str(path))
    for ext in ('.csv.zip', '.csv', '.zip'):
        if b.lower().endswith(ext):
            return b[:-len(ext)]
    return os.path.splitext(b)[0]


def open_log_bin(path):
    """(binary stream, uncompressed size) of a plain or zipped logfile; OSError on problems."""
    if not is_zip_log(path):
        return open(path, 'rb'), os.path.getsize(path)
    try:
        zf = zipfile.ZipFile(path)
        members = [zi for zi in zf.infolist()
                   if not zi.filename.endswith('/') and zi.filename.lower().endswith('.csv')]
        if len(members) > 1:
            zf.close()
            raise OSError(os.path.basename(path) + ' holds ' + str(len(members))
                          + ' csv files - use eping.py GENERATE REPORT (merges them) or unpack it')
        if members:
            fh = zf.open(members[0])
            fh._epinga_zip = zf              # keep the archive open while the member is read
            return fh, members[0].file_size
        zf.close()
    except zipfile.BadZipFile as e:
        raise OSError(str(e))
    raise OSError('no csv file inside ' + os.path.basename(path))


# ── stream-parse the CSV ──────────────────────────────────────────────────────
def list_sources(filename):
    """Distinct SOURCE values of a logfile (empty = 'local'); [] if the column is absent."""
    out = set()
    try:
        raw, _sz = open_log_bin(filename)
        with raw, io.TextIOWrapper(raw, encoding='utf-8', errors='replace', newline='') as fh:
            rd = csv.reader(fh)
            hdr = next(rd, None)
            if not hdr or 'SOURCE' not in hdr:
                return []
            i = hdr.index('SOURCE')
            h = hdr.index('HOSTNAME') if 'HOSTNAME' in hdr else 1
            for r in rd:
                if len(r) > i and len(r) > h and r[h] not in ('#COMMENT#', '#INFO#'):
                    out.add(r[i].strip() or 'local')
    except OSError as e:
        die(str(e))
    return sorted(out)


def analyse(filename, filter_hosts=None, ts_start=None, ts_end=None, quiet=False, source=None):
    source = set(source) if source else None     # selected SOURCE values

    hosts      = {}   # hostname -> HostStats
    host_order = []   # insertion order
    comments   = []   # [{'ts': datetime, 'text': str}, ...] - from '#COMMENT#' sentinel rows
    infos      = []   # [{'ts': datetime, 'text': str}, ...] - from '#INFO#' sentinel rows
    rows_read  = 0
    rows_skipped = 0  # malformed/truncated rows (no hostname, no timestamp, no state)
    pauses     = []   # [(start, end)] STOP..START periods (CHECK PAUSED / CHECK RESUMED comments)
    open_pause = None

    try:
        fh, file_size = open_log_bin(filename)
    except OSError as e:
        die(str(e))

    progress = Progress(file_size) if not quiet else None

    with fh:
        tracker = _ByteTracker(fh)
        reader  = csv.DictReader(tracker)

        # validate header
        required = {'HOSTNAME', 'TIMESTAMP', 'PREVIOUS_STATE', 'CURRENT_STATE',
                    'RTT', 'NO_OF_CHANGES'}
        if reader.fieldnames is None or not required.issubset(set(reader.fieldnames)):
            die(f'"{filename}" does not look like an eping logfile (wrong header).')

        has_meta = 'INV_HOSTNAME' in reader.fieldnames   # logs from eping.py 3.62+
        if source and 'SOURCE' not in reader.fieldnames:
            if source != {'local'}:
                die('"' + filename + '" has no SOURCE column (all rows are local).')
            source = None       # old log: everything is local
        last_src = {}           # hostname -> source of its previous row (any source)

        def field(row, key):
            # a truncated last line (log still being written) yields None for the
            # missing columns - never let that reach .strip()/comparisons
            return (row.get(key) or '').strip()

        for row in reader:
            rows_read += 1

            hostname = field(row, 'HOSTNAME')
            if not hostname:
                rows_skipped += 1
                continue

            if hostname in ('#COMMENT#', '#INFO#'):
                ts = parse_ts(field(row, 'TIMESTAMP'))
                if ts is None:
                    rows_skipped += 1
                    continue
                text = field(row, 'IP')
                if hostname == '#COMMENT#':
                    if text == 'CHECK PAUSED' and open_pause is None:
                        open_pause = ts
                    elif text == 'CHECK RESUMED' and open_pause is not None:
                        pauses.append((open_pause, ts))
                        open_pause = None
                if ts_start and ts < ts_start:
                    continue
                if ts_end   and ts > ts_end:
                    continue
                if text:
                    (comments if hostname == '#COMMENT#' else infos).append({'ts': ts, 'text': text})
                continue

            if filter_hosts and hostname not in filter_hosts:
                continue

            ts = parse_ts(field(row, 'TIMESTAMP'))
            if ts is None:
                rows_skipped += 1
                continue
            if open_pause is not None and ts > open_pause:
                pauses.append((open_pause, ts))     # eping restarted while paused
                open_pause = None
            if ts_start and ts < ts_start:
                continue
            if ts_end   and ts > ts_end:
                continue

            if source:
                src = field(row, 'SOURCE') or 'local'
                prev_src = last_src.get(hostname)
                last_src[hostname] = src
                if src not in source:
                    continue
                new_seg = prev_src is not None and prev_src not in source
            else:
                new_seg = False
            prev_state = field(row, 'PREVIOUS_STATE')
            cur_state  = field(row, 'CURRENT_STATE')
            if not cur_state:
                rows_skipped += 1        # truncated row - no usable state
                continue
            rtt_raw    = field(row, 'RTT')
            noc        = field(row, 'NO_OF_CHANGES')
            ip_raw     = field(row, 'IP')   # absent on older logfiles - fine, defaults to ''

            if hostname not in hosts:
                # initial state is the row's PREVIOUS_STATE (what the host was before
                # this row) so a first row that already carries a change counts as one
                hosts[hostname] = HostStats(ts, prev_state or cur_state, ip_raw)
                host_order.append(hostname)
            elif new_seg:
                hosts[hostname].new_segment(ts, prev_state)
            hosts[hostname].feed(ts, prev_state, cur_state, rtt_raw, noc, ip_raw)
            if has_meta:
                hs = hosts[hostname]
                for key, colname in META_LOG_COLS:
                    v = field(row, colname)
                    if v:
                        if hs.meta is None:
                            hs.meta = {}
                        hs.meta[key] = v

            if progress and rows_read % 5000 == 0:
                progress.update(tracker.bytes_read)
            if _PROG['file'] and rows_read % 2000 == 0:
                prog_write(tracker.bytes_read, file_size)

    if progress:
        progress.update(tracker.bytes_read)
        progress.done()

    if open_pause is not None:
        pauses.append((open_pause, datetime.datetime.max))
    for h in hosts.values():
        h.finalise()
        if pauses:
            h.add_pauses(pauses)

    comments.sort(key=lambda c: c['ts'])
    infos.sort(key=lambda i: i['ts'])
    if rows_skipped and not quiet:
        print(f'  {col(str(rows_skipped) + " malformed/truncated row(s) skipped", CORANGE)}')
    return hosts, host_order, rows_read, comments, infos


# ── state colour ──────────────────────────────────────────────────────────────
def state_col(state):
    if state == 'UP':      return col(state.center(6), CGREEN)
    if state == 'DOWN':    return col(state.center(6), CRED)
    if state == 'NO-DNS':  return col(state.center(6), CRED)
    return state.center(6)

def fmt_td(td):
    total = int(td.total_seconds())
    h, rem = divmod(total, 3600)
    m, s   = divmod(rem, 60)
    if h:   return f'{h}h {m:02d}m {s:02d}s'
    if m:   return f'{m}m {s:02d}s'
    return  f'{s}s'

# ── print per-host detail ─────────────────────────────────────────────────────
def print_host(hostname, s, show_changes, comments=None):
    header_line(hostname)

    if show_changes and (s.changes or comments):
        # comments are a global timeline - only show ones logged while this host
        # was actually being observed (its first_ts..last_ts window), merged
        # chronologically with its own UP/DOWN transitions (same as the HTML report)
        relevant_comments = [
            c for c in (comments or [])
            if (not s.first_ts or c['ts'] >= s.first_ts) and (not s.last_ts or c['ts'] <= s.last_ts)
        ]
        timeline = (
            [('change', ts, frm, to) for ts, frm, to in s.changes]
            + [('comment', c['ts'], c['text'], None) for c in relevant_comments]
        )
        # same second: comment first (eping logs its SOURCE SWITCH comments before the rows they cause)
        timeline.sort(key=lambda e: (e[1] or datetime.datetime.min, 0 if e[0] == 'comment' else 1))
        for kind, ts, a, b in timeline:
            ts_str = ts.strftime(TS_FMT) if ts else '?'
            if kind == 'comment':
                print(f'  {ts_str}  {col("COMMENT: " + a, CORANGE)}')
            else:
                arrow = f'{state_col(a)} → {state_col(b)}'
                print(f'  {ts_str}  {arrow}')
        print()

    # RTT line
    if s.has_rtt:
        rtt_line = (f'  RTT  min: {col(str(round(s.rtt_min,2))+" ms", CCYAN)}'
                    f'  max: {col(str(round(s.rtt_max,2))+" ms", CCYAN)}'
                    f'  avg: {col(str(s.rtt_avg)+" ms", CCYAN)}'
                    f'  samples: {s.rtt_cnt}')
        print(rtt_line)
    else:
        print(f'  RTT  {col("no data", CDIM)}')

    # uptime line
    span_s    = s.total_span.total_seconds()
    up_pct    = s.uptime_pct
    pct_colour = CGREEN if up_pct >= 99 else (CORANGE if up_pct >= 90 else CRED)
    up_bar_len = 40
    filled     = int(up_bar_len * up_pct / 100) if span_s > 0 else 0
    up_bar     = col('█' * filled, CGREEN) + col('░' * (up_bar_len - filled), CRED)

    print(f'  Uptime  [{up_bar}] {col(f"{up_pct:.2f} %", pct_colour)}'
          f'  ↑ {fmt_td(s.time_up)}  ↓ {fmt_td(s.time_down + s.time_nodns)}'
          f'  span: {fmt_td(s.total_span)}')

    final_state = s.current_state
    print(f'  State changes: {s.real_changes}'
          f'  │  Final state: {state_col(final_state)}'
          f'  │  Log: {s.first_ts.strftime(TS_FMT) if s.first_ts else "?"}'
          f' → {s.last_ts.strftime(TS_FMT)  if s.last_ts  else "?"}')
    print()


# ── grid printer for host lists ───────────────────────────────────────────────
def print_host_grid(lst, indent=2, pad=2):
    """Print a list of hostnames in a tidy multi-column grid.
    col_width is derived from the longest hostname so names never break mid-word.
    cell_w = indent + col_width per cell (indent is prepended to every cell)."""
    if not lst:
        print(' ' * indent + col('–', CDIM))
        return
    try:
        term_w = os.get_terminal_size().columns
    except OSError:
        term_w = W
    col_width = max(len(h) for h in lst) + pad
    cell_w    = indent + col_width          # every cell carries its own indent
    cols      = max(1, term_w // cell_w)
    for i, h in enumerate(lst):
        end_char = '\n' if (i + 1) % cols == 0 or i == len(lst) - 1 else ''
        print(' ' * indent + h.ljust(col_width), end=end_char)
    if len(lst) % cols != 0:
        print()   # ensure final newline


# ── summary table ─────────────────────────────────────────────────────────────
def print_summary(hosts, host_order, sort_by='name'):
    # ── categorise ────────────────────────────────────────────────────────────
    always_up, always_down, always_nodns, flapping = [], [], [], []
    for h in host_order:
        s = hosts[h]
        if s.real_changes == 0:
            if   s.current_state == 'UP':     always_up.append(h)
            elif s.current_state == 'DOWN':   always_down.append(h)
            elif s.current_state == 'NO-DNS': always_nodns.append(h)
        else:
            flapping.append(h)

    # ── sort host_order for the detail table ──────────────────────────────────
    if sort_by == 'flapping':
        ordered = sorted(host_order, key=lambda h: hosts[h].real_changes, reverse=True)
    elif sort_by == 'uptime':
        ordered = sorted(host_order, key=lambda h: hosts[h].uptime_pct)
    elif sort_by == 'rtt':
        ordered = sorted(host_order, key=lambda h: hosts[h].rtt_avg)
    else:
        ordered = host_order   # insertion / log order

    # ── table ─────────────────────────────────────────────────────────────────
    print()
    hr('═')
    sort_note = f'  sorted by: {sort_by}' if sort_by != 'name' else ''
    header_line(f'SUMMARY{sort_note}', '═')
    hr('═')

    col_h  = 32
    col_st =  8
    col_up = 10
    col_rt = 10
    col_ch =  8

    hdr = (f'  {"HOST":<{col_h}} {"STATE":^{col_st}} {"UPTIME %":>{col_up}}'
           f'  {"MIN RTT":>{col_rt}}  {"AVG RTT":>{col_rt}}  {"MAX RTT":>{col_rt}}'
           f'  {"CHANGES":>{col_ch}}')
    print(col(hdr, CBOLD))
    hr()

    prev_cat = None
    for h in ordered:
        s = hosts[h]

        # category separator when sorting by flapping
        if sort_by == 'flapping':
            cat = 'flap' if s.real_changes > 0 else s.current_state
            if cat != prev_cat:
                if prev_cat is not None:
                    hr('·')
                prev_cat = cat

        up_pct     = s.uptime_pct
        pct_colour = CGREEN if up_pct >= 99 else (CORANGE if up_pct >= 90 else CRED)
        min_rtt    = f'{s.rtt_min} ms' if s.has_rtt else '-'
        avg_rtt    = f'{s.rtt_avg} ms' if s.has_rtt else '-'
        max_rtt    = f'{s.rtt_max} ms' if s.has_rtt else '-'
        noc        = str(s.real_changes)
        noc_col    = CORANGE if s.real_changes > 0 else CDIM

        line = (f'  {h:<{col_h}} {state_col(s.current_state):^{col_st}}'
                f' {col(f"{up_pct:8.2f} %", pct_colour)}'
                f'  {min_rtt:>{col_rt}}  {avg_rtt:>{col_rt}}  {max_rtt:>{col_rt}}'
                f'  {col(noc.rjust(col_ch), noc_col)}')
        print(line)

    hr()

    # ── bucket sections ───────────────────────────────────────────────────────
    def bucket(label, colour, lst, sort_fn=sort_hosts):
        hr()
        label_str = col(f'  {label}', colour + CBOLD)
        cnt_str   = col(f'{len(lst):>5}', CBOLD)
        print(f'{label_str}  {cnt_str}')
        hr('·')
        print_host_grid(sort_fn(lst))
        print()

    bucket('Always UP   ', CGREEN,  always_up)
    bucket('Flapping    ', CORANGE, flapping,
           sort_fn=lambda l: sorted(l, key=lambda h: hosts[h].real_changes, reverse=True))
    bucket('Always DOWN ', CRED,    always_down)
    bucket('No DNS      ', CRED,    always_nodns)
    hr()


# ── HTML export ───────────────────────────────────────────────────────────────
def build_report_data(hosts, host_order, filename, rows_read, base='', comments=None, infos=None, source=''):
    """Serialize all analysis data to a plain dict for JSON embedding."""
    rows = []
    for h in host_order:
        s = hosts[h]
        initial_state = s.changes[0][1] if s.changes else s.current_state
        rows.append({
            'name':          h,
            'state':         s.current_state,
            'initial_state': initial_state,
            'uptime':        round(s.uptime_pct, 2),
            'rtt_min':       round(s.rtt_min, 2) if s.has_rtt else None,
            'rtt_max':       round(s.rtt_max, 2) if s.has_rtt else None,
            'rtt_avg':       s.rtt_avg           if s.has_rtt else None,
            'rtt_cnt':       s.rtt_cnt,
            'changes':       s.real_changes,
            'ip':            s.ip,
            'inv_name':      (s.meta or {}).get('inv_name', ''),
            'serial':        (s.meta or {}).get('serial', ''),
            'model':         (s.meta or {}).get('model', ''),
            'location':      (s.meta or {}).get('location', ''),
            'sysloc':        (s.meta or {}).get('sysloc', ''),
            'type':          (s.meta or {}).get('type', ''),
            'comment':       (s.meta or {}).get('comment', ''),
            'time_up':       fmt_td(s.time_up),
            'time_down':     fmt_td(s.time_down + s.time_nodns),
            'span':          fmt_td(s.total_span),
            'first_ts':      s.first_ts.strftime(TS_FMT) if s.first_ts else '',
            'last_ts':       s.last_ts.strftime(TS_FMT)  if s.last_ts  else '',
            'gaps': [[a.strftime(TS_FMT), b.strftime(TS_FMT)] for a, b in s.gaps],
            'events': [
                {'ts': (ts.strftime(TS_FMT) if ts else ''), 'frm': frm, 'to': to}
                for ts, frm, to in s.changes
            ],
        })

    all_first = [r['first_ts'] for r in rows if r['first_ts']]
    all_last  = [r['last_ts']  for r in rows if r['last_ts']]
    comment_rows = [
        {'ts': c['ts'].strftime(TS_FMT), 'text': c['text']}
        for c in (comments or [])
    ]
    info_rows = [
        {'ts': i['ts'].strftime(TS_FMT), 'text': i['text']}
        for i in (infos or [])
    ]
    return {
        'filename':     filename,
        'source':       source or '',
        'base':         base,
        'generated':    datetime.datetime.now().strftime(TS_FMT),
        'rows_read':    rows_read,
        'global_start': min(all_first) if all_first else '',
        'global_end':   max(all_last)  if all_last  else '',
        'hosts':        rows,
        'comments':     comment_rows,
        'infos':        info_rows,
    }


def _is_ip_host(name):
    """Same intent as the report's client-side isIpHost() - true for a raw
    IPv4/IPv6 literal host, false for a hostname."""
    try:
        ipaddress.ip_address(name)
        return True
    except ValueError:
        return False


def count_duplicate_hosts(rows):
    """Hosts monitored under both a hostname and an IP resolving to it - both
    sides of every such pair count (mirrors REDUNDANT_IPS/REDUNDANT_NAMES in the
    report's JS - see there for the exact matching rule). Used for the
    DUPLICATES stat card, independent of which dedup mode is selected.
    """
    name_hosts_ips = set(h['ip'] for h in rows if h['ip'] and not _is_ip_host(h['name']))
    ip_hosts_names = set(h['name'] for h in rows if _is_ip_host(h['name']))
    n = 0
    for h in rows:
        if _is_ip_host(h['name']):
            if h['name'] in name_hosts_ips:
                n += 1
        else:
            if h['ip'] and h['ip'] in ip_hosts_names:
                n += 1
    return n


def generate_html(data, out_path):
    # per-source datasets (source switch in the report) are embedded separately from the main data
    variants  = data.get('variants') or []
    main_data = {k: v for k, v in data.items() if k != 'variants'}
    json_data = json.dumps(main_data, ensure_ascii=False).replace('</script', '<\\/script')
    variants_json = json.dumps(variants, ensure_ascii=False).replace('</script', '<\\/script')
    comments  = data.get('comments') or []
    if comments:
        comment_rows_html = '\n'.join(
            f'<div class="comment-row"><span class="comment-ts">{html_lib.escape(c["ts"])}</span>'
            f'<span class="comment-text">{html_lib.escape(c["text"])}</span></div>'
            for c in comments
        )
    else:
        comment_rows_html = '<div class="comment-row comment-empty">No comments logged.</div>'
    infos = data.get('infos') or []
    if infos:
        info_rows_html = '\n'.join(
            f'<div class="comment-row"><span class="comment-ts">{html_lib.escape(i["ts"])}</span>'
            f'<span class="comment-text info-text">{html_lib.escape(i["text"])}</span></div>'
            for i in infos
        )
    else:
        info_rows_html = '<div class="comment-row comment-empty">No info logged.</div>'
    n_total   = len(data['hosts'])
    n_up      = sum(1 for h in data['hosts'] if h['changes'] == 0 and h['state'] == 'UP')
    n_flap    = sum(1 for h in data['hosts'] if h['changes'] > 0)
    n_down    = sum(1 for h in data['hosts'] if h['changes'] == 0 and h['state'] == 'DOWN')
    n_nodns   = sum(1 for h in data['hosts'] if h['changes'] == 0 and h['state'] == 'NO-DNS')
    n_dup     = count_duplicate_hosts(data['hosts'])
    filename_html = html_lib.escape(str(data['filename']))

    html = f"""<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>epinga – {filename_html}</title>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzRhM2IzNCI+CiAgPGVsbGlwc2UgY3g9IjEyIiBjeT0iMTYuNSIgcng9IjUuNCIgcnk9IjQuMyIvPgogIDxlbGxpcHNlIGN4PSI1LjIiIGN5PSIxMC41IiByeD0iMi41IiByeT0iMy4xIi8+CiAgPGVsbGlwc2UgY3g9IjE4LjgiIGN5PSIxMC41IiByeD0iMi41IiByeT0iMy4xIi8+CiAgPGVsbGlwc2UgY3g9IjguOSIgY3k9IjUuNiIgcng9IjIuNCIgcnk9IjMuMSIvPgogIDxlbGxpcHNlIGN4PSIxNS4xIiBjeT0iNS42IiByeD0iMi40IiByeT0iMy4xIi8+Cjwvc3ZnPg==">
<style>
:root {{
  --bg:      #0d1117;
  --bg2:     #161b22;
  --bg3:     #21262d;
  --border:  #30363d;
  --text:    #c9d1d9;
  --dim:     #8b949e;
  --green:   #3fb950;
  --red:     #f85149;
  --orange:  #d29922;
  --cyan:    #58a6ff;
  --font:    'Fira Code','Cascadia Code','Consolas',monospace;
}}
:root.light {{
  --bg:      #f6f8fa;
  --bg2:     #ffffff;
  --bg3:     #eaeef2;
  --border:  #d0d7de;
  --text:    #1f2328;
  --dim:     #656d76;
  --green:   #1a7f37;
  --red:     #d1242f;
  --orange:  #9a6700;
  --cyan:    #0969da;
}}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ background: var(--bg); color: var(--text); font-family: var(--font);
       font-size: 13px; line-height: 1.5; }}
a {{ color: var(--cyan); text-decoration: none; }}

/* ── header ── */
.hdr {{ background: var(--bg2); border-bottom: 1px solid var(--border);
        padding: 16px 24px; display: flex; align-items: center; justify-content: space-between; gap: 16px; }}
.hdr-left {{ display: flex; flex-direction: column; }}
.hdr h1 {{ font-size: 18px; color: var(--text); letter-spacing: .5px; }}
.hdr h1 .ver {{ font-size: 10px; font-weight: 400; color: var(--dim); letter-spacing: normal; margin-left: 6px; }}
.hdr .meta {{ color: var(--dim); font-size: 11px; margin-top: 4px; }}

/* ── stat cards ── */
.cards {{ display: flex; gap: 12px; padding: 16px 24px; flex-wrap: wrap; }}
.card {{ background: var(--bg2); border: 1px solid var(--border); border-radius: 6px;
         padding: 12px 20px; min-width: 120px; text-align: center; height: 73px;
         box-sizing: border-box; display: flex; flex-direction: column; }}
.card .num, .card .info {{ flex: 1 1 0; min-height: 0; display: flex;
                           align-items: flex-end; justify-content: center; }}
.card .num {{ font-size: 28px; font-weight: 700; }}
.card .lbl, .card .info-sub {{ flex: 0 0 auto; font-size: 11px; color: var(--dim); }}
.card.up    .num {{ color: var(--green);  }}
.card.flap  .num {{ color: var(--orange); }}
.card.down  .num {{ color: var(--red);    }}
.card.nodns .num {{ color: var(--red);    }}
.card.dup   .num {{ color: var(--cyan);   }}
.card.dup .info {{ font-size: 14px; font-weight: 700; line-height: 1.2;
                   color: var(--green); letter-spacing: .3px; }}
.card.dup .info-sub {{ font-weight: 400; }}
.cards {{ align-items: center; }}
/* inventory drop-downs: the free space right of the stat cards */
.meta-filters {{ display: flex; gap: 12px; flex: 1 1 320px; flex-wrap: wrap; align-items: center;
                 margin-left: 4px; padding-left: 16px; border-left: 1px solid var(--border); }}
.meta-filters:empty {{ display: none; }}
.mf {{ display: flex; flex-direction: column; gap: 3px; flex: 0 0 104px; width: 104px; }}
.mf label {{ font-size: 11px; color: var(--dim); }}
.mf select {{ background: var(--bg2); border: 1px solid var(--border); border-radius: 6px;
              color: var(--text); font-family: var(--font); font-size: 12px; padding: 6px 10px;
              outline: none; width: 100%; text-overflow: ellipsis; }}
/* narrow until used: grows in the flow while focused, neighbours move aside */
.mf:focus-within {{ flex-basis: 200px; width: 200px; max-width: 100%; }}
.mf select:focus {{ border-color: var(--cyan); }}
.side-widget {{ margin-left: auto; width: 190px; display: flex; justify-content: center; }}
.cat-link {{ display: block; line-height: 0; }}
.cat {{ height: 90px; width: auto; display: block; filter: drop-shadow(0 4px 10px rgba(0,0,0,.25)); }}
.cat .tail {{ transform-origin: 152px 300px; animation: wag 2.6s ease-in-out infinite; }}
.cat .lid  {{ transform: scaleY(0); transform-origin: center; animation: blink 5s infinite; }}
@keyframes wag {{ 0%,100%{{ transform: rotate(0deg); }} 50%{{ transform: rotate(-11deg); }} }}
@keyframes blink {{ 0%,94%,100%{{ transform: scaleY(0); }} 96%,98%{{ transform: scaleY(1); }} }}
@media (prefers-reduced-motion: reduce) {{ .cat .tail, .cat .lid {{ animation: none; }} }}
.paw-title {{ color: var(--dim); vertical-align: -2px; margin-right: 4px; }}

/* ── toolbar ── */
.toolbar {{ display: flex; gap: 10px; padding: 0 24px 12px; flex-wrap: wrap;
            align-items: center; }}
.toolbar input, .toolbar select, .toolbar button {{
  background: var(--bg2); border: 1px solid var(--border); border-radius: 6px;
  color: var(--text); font-family: var(--font); font-size: 12px;
  padding: 6px 10px; outline: none; }}
.toolbar input {{ width: 260px; }}
.toolbar input:focus, .toolbar select:focus {{ border-color: var(--cyan); }}
.toolbar input.invalid {{ border-color: var(--red); }}
.toolbar label {{ color: var(--dim); font-size: 12px; }}
.toolbar button {{ cursor: pointer; }}
.toolbar button:hover {{ border-color: var(--cyan); }}
.toolbar button.active {{ background: var(--orange); border-color: var(--orange); color: var(--bg); font-weight: 600; }}
#btnShowIp.active {{ background: var(--green); border-color: var(--green); color: var(--bg); font-weight: 600; }}
.sep {{ width: 1px; height: 20px; background: var(--border); align-self: center; }}
.toolbar .site-link {{ display: flex; align-items: center; gap: 6px;
  color: var(--dim); text-decoration: none; font-size: 12px;
  padding: 4px 10px; border-radius: 999px; border: 1px solid var(--border); }}
.toolbar .site-link:hover {{ color: var(--cyan); border-color: var(--cyan); }}
.toolbar .site-link svg {{ flex: none; }}

/* ── table ── */
.tbl-wrap {{ padding: 0 24px 24px; overflow-x: auto; }}
/* comments + hostlist are static buckets outside #buckets (which supplies its
   own 24px via .buckets padding for the dynamically-generated buckets) - give
   both the same horizontal margin so all bucket boxes line up */
.bucket.hostlist, .bucket.comments, .bucket.info {{ margin: 0 24px 20px; }}
.bucket.hostlist .tbl-wrap {{ padding: 0; }}
.bucket.comments .bucket-body, .bucket.info .bucket-body {{ padding: 10px 16px; }}
.comment-row {{ display: flex; gap: 14px; padding: 5px 0; border-bottom: 1px solid var(--border); font-size: 13px; }}
.comment-row:last-child {{ border-bottom: none; }}
.comment-ts {{ color: var(--dim); white-space: nowrap; font-variant-numeric: tabular-nums; }}
.comment-text {{ color: var(--text); word-break: break-word; }}
.comment-text.info-text {{ color: var(--cyan); font-family: var(--font); }}
.comment-row.comment-empty {{ color: var(--dim); font-style: italic; }}
.bucket.collapsed.hostlist .tbl-wrap {{ display: none; }}
table {{ width: 100%; border-collapse: collapse; }}
thead th {{
  background: var(--bg3); border: 1px solid var(--border); padding: 8px 12px;
  text-align: left; cursor: pointer; user-select: none; white-space: nowrap;
  color: var(--dim); font-size: 11px; letter-spacing: .6px;
  position: sticky; top: 0; z-index: 2; }}
thead th:hover {{ color: var(--text); }}
thead th.sort-asc::after  {{ content: ' ▲'; color: var(--cyan); }}
thead th.sort-desc::after {{ content: ' ▼'; color: var(--cyan); }}
thead th .sort-num {{ font-size: 9px; color: var(--cyan); font-weight: 700;
                       margin-left: 3px; vertical-align: super; }}
tbody tr {{
  border-bottom: 1px solid var(--border); cursor: pointer;
  transition: background .1s; }}
tbody tr:hover {{ background: var(--bg2); }}
tbody tr.expanded {{ background: var(--bg2); }}
tbody tr.detail-row {{ cursor: default; background: var(--bg3); }}
tbody tr.detail-row:hover {{ background: var(--bg3); }}
td {{ padding: 7px 12px; white-space: nowrap; }}
td.host {{ font-weight: 600; color: var(--text); }}
.host-ip {{ font-weight: 400; color: var(--dim); font-size: 12px; margin-left: 6px; }}

/* state badge */
.badge {{
  display: inline-block; width: 72px; padding: 2px 0; border-radius: 12px;
  font-size: 11px; font-weight: 700; letter-spacing: .4px;
  text-align: center; }}
.badge.UP      {{ background: rgba(63,185,80,.12);  color: var(--green);  border: 1px solid var(--green); }}
.badge.DOWN    {{ background: rgba(248,81,73,.12);  color: var(--red);    border: 1px solid var(--red); }}
.badge.NO-DNS  {{ background: rgba(248,81,73,.12);  color: var(--red);    border: 1px solid var(--red); }}
.badge.FLAPPING{{ background: rgba(210,153,34,.12); color: var(--orange); border: 1px solid var(--orange); }}

/* uptime bar */
.bar-wrap {{ width: 120px; height: 8px; background: rgba(248,81,73,.2);
             border-radius: 4px; overflow: hidden; display: inline-block;
             vertical-align: middle; margin-right: 6px; }}
.bar-fill {{ display: block; height: 100%; border-radius: 4px; }}
.pct-green  {{ color: var(--green);  }}
.pct-orange {{ color: var(--orange); }}
.pct-red    {{ color: var(--red);    }}

/* detail row */
.detail-inner {{ padding: 12px 16px; }}
.detail-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 16px;
                max-width: 900px; }}
.detail-section h4 {{ color: var(--dim); font-size: 11px; margin-bottom: 8px;
                       letter-spacing: .5px; }}
.events {{ display: flex; flex-direction: column; gap: 4px; }}
.event.comment-event {{ color: var(--orange); }}
.event.comment-event .comment-marker {{ margin-right: 2px; }}
.event.comment-event .comment-event-text {{ font-style: italic; word-break: break-word; }}
.event {{ display: flex; align-items: center; gap: 10px; font-size: 12px; }}
.event .ts  {{ color: var(--dim); width: 155px; flex-shrink: 0; }}
.arrow {{ color: var(--dim); }}
.stat-list {{ display: flex; flex-direction: column; gap: 4px; font-size: 12px; }}
.stat-list .kv {{ display: flex; gap: 8px; }}
.stat-list .k {{ color: var(--dim); width: 90px; }}
.stat-list .v {{ color: var(--text); }}
.chevron {{ float: right; color: var(--dim); transition: transform .2s; }}
.expanded .chevron {{ transform: rotate(180deg); }}
tr.hidden {{ display: none; }}

/* ── buckets ── */
.buckets {{ padding: 0 24px 40px; }}
.bucket {{ margin-bottom: 20px; }}
.bucket h3 {{
  font-size: 12px; letter-spacing: .6px; padding: 6px 12px;
  background: var(--bg2); border: 1px solid var(--border);
  border-radius: 6px 6px 0 0; display: flex; justify-content: space-between;
  align-items: center; cursor: default; }}
.bucket-toggle {{ display: flex; align-items: center; gap: 8px; cursor: pointer;
                   flex: 1; user-select: none; }}
.bucket-chevron {{ color: var(--dim); transition: transform .2s; display: inline-block; }}
.bucket.collapsed .bucket-chevron {{ transform: rotate(-90deg); }}
/* padding + a compensating negative margin enlarge the actual clickable hit
   area well beyond the small arrow glyph itself, without shifting where the
   glyph visually sits or nudging the layout around it */
.sort-btn {{ color: var(--cyan); font-size: 11px; cursor: pointer; user-select: none;
             letter-spacing: 0; display: inline-block; border-radius: 4px;
             padding: 7px 9px; margin: -7px -9px -7px calc(2ch - 9px); }}
.sort-btn:hover {{ color: var(--text); background: rgba(255,255,255,.08); }}
.bucket.collapsed .bucket-body {{ display: none; }}
.bucket-actions {{ display: flex; align-items: center; gap: 10px; }}
.dl-btn {{
  background: none; border: 1px solid var(--border); border-radius: 4px;
  color: var(--dim); cursor: pointer; font-size: 12px; line-height: 1;
  padding: 3px 7px; font-family: var(--font);
  display: inline-flex; align-items: center; gap: 4px; }}
.dl-btn:hover {{ color: var(--text); border-color: var(--cyan); }}
.bucket-body {{ border: 1px solid var(--border); border-top: none;
                border-radius: 0 0 6px 6px; padding: 12px; }}
.tag-list {{ display: flex; flex-wrap: wrap; gap: 6px; }}
.tag {{
  padding: 2px 10px; border-radius: 4px; font-size: 12px;
  border: 1px solid; cursor: default; }}
.tag.up    {{ background:rgba(63,185,80,.1);  color:var(--green);  border-color:var(--green); }}
.tag.flap  {{ background:rgba(210,153,34,.1); color:var(--orange); border-color:var(--orange); }}
.tag.down  {{ background:rgba(248,81,73,.1);  color:var(--red);    border-color:var(--red); }}
.tag.nodns {{ background:rgba(248,81,73,.1);  color:var(--red);    border-color:var(--red); }}
.tag .chg {{ font-size:10px; opacity:.7; }}

/* ── theme toggle ── */
.theme-btn {{
  background: var(--bg3); border: 1px solid var(--border); border-radius: 6px;
  color: var(--text); font-family: var(--font); font-size: 12px;
  padding: 5px 12px; cursor: pointer; transition: background .15s;
  white-space: nowrap; flex-shrink: 0; }}
.theme-btn:hover {{ background: var(--border); }}

/* ── footer ── */
footer {{ display:flex; align-items:center; justify-content:center; gap:8px;
          padding:16px; color:var(--dim); font-size:11px;
          border-top:1px solid var(--border); }}
footer svg {{ flex:none; }}
footer a {{ color: inherit; text-decoration: underline; text-decoration-color: var(--border); }}
footer a:hover {{ color: var(--text); text-decoration-color: currentColor; }}
</style>
</head>
<body>

<div class="hdr">
  <div class="hdr-left">
    <h1><svg class="paw-title" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <ellipse cx="12" cy="16.5" rx="5.4" ry="4.3"/>
      <ellipse cx="5.2" cy="10.5" rx="2.5" ry="3.1"/>
      <ellipse cx="18.8" cy="10.5" rx="2.5" ry="3.1"/>
      <ellipse cx="8.9" cy="5.6" rx="2.4" ry="3.1"/>
      <ellipse cx="15.1" cy="5.6" rx="2.4" ry="3.1"/>
    </svg>epinga &nbsp;·&nbsp; Analysis Report<small class="ver">v{VERSION}</small></h1>
    <div class="meta">
      File: <strong>{filename_html}</strong> &nbsp;|&nbsp;
      <span id="metaSrc">{('Source: <strong>' + html_lib.escape(str(data.get('source'))) + '</strong> &nbsp;|&nbsp; ') if data.get('source') else ''}</span>
      Generated: {data['generated']} &nbsp;|&nbsp;
      <span id="metaRows">{data['rows_read']:,}</span> rows &nbsp;|&nbsp;
      <span id="metaHosts">{n_total}</span> hosts &nbsp;|&nbsp;
      <span id="shownHosts">{n_total} shown</span>
    </div>
  </div>
  <button class="theme-btn" onclick="toggleTheme()" id="themeBtn">☀ Light</button>
</div>

<div class="cards">
  <div class="card" id="cardTotal"><div class="num">{n_total}</div><div class="lbl">TOTAL HOSTS</div></div>
  <div class="card up" id="cardUp">  <div class="num">{n_up}</div>   <div class="lbl">ALWAYS UP</div></div>
  <div class="card flap" id="cardFlap"><div class="num">{n_flap}</div> <div class="lbl">FLAPPING</div></div>
  <div class="card down" id="cardDown"><div class="num">{n_down}</div> <div class="lbl">ALWAYS DOWN</div></div>
  <div class="card nodns" id="cardNodns"><div class="num">{n_nodns}</div><div class="lbl">NO-DNS</div></div>
  <div class="card dup" id="cardDup"><div class="num">{n_dup}</div><div class="lbl">DUPLICATES</div></div>
  <div class="meta-filters" id="metaFilters"></div>
  <div class="side-widget">
  <a href="https://jeitler.cc/nelly/" class="cat-link" target="_blank" rel="noopener" aria-label="More about Nelly">
  <svg class="cat" viewBox="0 0 320 340" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Nelly, a cute cartoon cat">
    <title>Nelly</title>
    <g class="tail">
      <path d="M152 300 C 220 312, 268 286, 262 236 C 259 208, 232 200, 222 220 C 214 236, 232 244, 240 232"
            pathLength="100" fill="none" stroke="#fdfaf6" stroke-width="17" stroke-linecap="round"/>
      <path d="M152 300 C 220 312, 268 286, 262 236 C 259 208, 232 200, 222 220 C 214 236, 232 244, 240 232"
            pathLength="100" fill="none" stroke="#3f3733" stroke-width="17" stroke-linecap="round"
            stroke-dasharray="24 100" stroke-dashoffset="-6"/>
      <path d="M152 300 C 220 312, 268 286, 262 236 C 259 208, 232 200, 222 220 C 214 236, 232 244, 240 232"
            pathLength="100" fill="none" stroke="#f0a049" stroke-width="17" stroke-linecap="round"
            stroke-dasharray="26 100" stroke-dashoffset="-40"/>
      <path d="M152 300 C 220 312, 268 286, 262 236 C 259 208, 232 200, 222 220 C 214 236, 232 244, 240 232"
            pathLength="100" fill="none" stroke="#3f3733" stroke-width="17" stroke-linecap="round"
            stroke-dasharray="20 100" stroke-dashoffset="-76"/>
    </g>
    <ellipse cx="160" cy="252" rx="86" ry="66" fill="#fdfaf6"/>
    <path d="M92 216 C 108 200, 138 198, 150 214 C 160 228, 140 246, 118 244 C 100 242, 86 230, 92 216 Z" fill="#f0a049"/>
    <path d="M206 288 C 226 280, 240 262, 238 244 C 226 268, 208 276, 192 278 Z" fill="#3f3733"/>
    <ellipse cx="126" cy="308" rx="26" ry="15" fill="#fdfaf6" stroke="#e8ded4" stroke-width="2"/>
    <ellipse cx="194" cy="308" rx="26" ry="15" fill="#fdfaf6" stroke="#e8ded4" stroke-width="2"/>
    <path d="M118 306v7M126 304v9M134 306v7" stroke="#e0d3c7" stroke-width="2.5" stroke-linecap="round"/>
    <path d="M186 306v7M194 304v9M202 306v7" stroke="#e0d3c7" stroke-width="2.5" stroke-linecap="round"/>
    <path d="M84 108 L 82 46 L 132 82 Z" fill="#f0a049"/>
    <path d="M92 100 L 91 64 L 122 86 Z" fill="#ffc0cb"/>
    <path d="M236 108 L 238 46 L 188 82 Z" fill="#3f3733"/>
    <path d="M228 100 L 229 64 L 198 86 Z" fill="#ffc0cb"/>
    <ellipse cx="160" cy="146" rx="88" ry="78" fill="#fdfaf6"/>
    <path d="M160 68 C 200 68, 234 92, 242 128 C 226 140, 200 132, 186 112 C 176 96, 168 78, 160 68 Z" fill="#3f3733"/>
    <path d="M160 68 C 122 70, 92 92, 82 122 C 100 130, 122 120, 134 102 C 143 88, 152 76, 160 68 Z" fill="#f0a049"/>
    <path d="M232 176 C 224 196, 208 210, 190 216 C 200 196, 214 182, 232 176 Z" fill="#f0a049"/>
    <ellipse cx="128" cy="150" rx="15" ry="17" fill="#3f3733"/>
    <ellipse cx="192" cy="150" rx="15" ry="17" fill="#3f3733"/>
    <circle cx="133" cy="144" r="5.5" fill="#fff"/>
    <circle cx="197" cy="144" r="5.5" fill="#fff"/>
    <circle cx="124" cy="157" r="2.5" fill="#fff" opacity=".8"/>
    <circle cx="188" cy="157" r="2.5" fill="#fff" opacity=".8"/>
    <ellipse class="lid" cx="128" cy="150" rx="16" ry="18" fill="#fdfaf6"/>
    <ellipse class="lid" cx="192" cy="150" rx="16" ry="18" fill="#fdfaf6"/>
    <ellipse cx="104" cy="176" rx="15" ry="10" fill="#ffb7c5" opacity=".65"/>
    <ellipse cx="216" cy="176" rx="15" ry="10" fill="#ffb7c5" opacity=".65"/>
    <path d="M152 176 L 168 176 L 160 186 Z" fill="#ff9aa8"/>
    <path d="M160 186 C 160 196, 150 198, 145 192 M160 186 C 160 196, 170 198, 175 192"
          fill="none" stroke="#3f3733" stroke-width="3" stroke-linecap="round"/>
    <ellipse cx="143.3" cy="183.5" rx="4.2" ry="3.6" fill="#f0a049"/>
    <path d="M96 166 L 60 158 M96 176 L 58 178 M96 186 L 62 196" stroke="#c9b8ab" stroke-width="3" stroke-linecap="round"/>
    <path d="M224 166 L 260 158 M224 176 L 262 178 M224 186 L 258 196" stroke="#c9b8ab" stroke-width="3" stroke-linecap="round"/>
  </svg>
  </a>
  </div>
</div>

<div class="toolbar">
  <label>Filter:</label>
  <input id="search" type="text" placeholder="hostname/IP or /regex/ …" title="plain text or a regex (case-insensitive), matched against hostname, IP and the inventory fields (inventory hostname, serial, model, location, sysLocation, type)" oninput="applyFilter()">
  <label>Show:</label>
  <select id="stateFilter" onchange="applyFilter()">
    <option value="">ALL HOSTS</option>
    <option value="ALWAYS-UP">ALWAYS-UP</option>
    <option value="UP+FLAP">UP+FLAPPING</option>
    <option value="FLAP">FLAPPING-ONLY</option>
    <option value="ALWAYS-DOWN">ALWAYS-DOWN</option>
    <option value="DOWN+FLAP">DOWN+FLAPPING</option>
    <option value="NO-DNS">NO-DNS</option>
  </select>
  <label>Sort:</label>
  <select id="sortSel" onchange="sortBySelect()">
    <option value="">– log order –</option>
    <option value="name">Name</option>
    <option value="uptime">Uptime %</option>
    <option value="rtt_avg">Avg RTT</option>
    <option value="changes">Changes</option>
  </select>
  <button id="btnShowIp" onclick="toggleShowIp()"
          title="Switch every host's displayed label between hostname and IP">IP View</button>
  <select id="dedupSel" onchange="onDedupSelectChange()" title="Deduplication mode for hosts monitored under both a hostname and an IP">
    <option value="" selected>No deduplication</option>
    <option value="ip">Prefer IP address</option>
    <option value="name">Prefer hostname</option>
  </select>
  <select id="srcSel" onchange="switchSource(this.value)" style="display:none"
          title="Source of the measurement (local / jump host): every source is analysed on its own - uptime, RTT, changes and timeline"></select>
  <button id="btnResetFilters" onclick="resetFilters()" title="Clear the text filter, the Show selection and all inventory drop-downs">Reset</button>
  <span class="sep" id="sepDownload"></span>
  <button id="btnDownloadHtml" onclick="downloadHtml()" title="Save this report as a standalone .html file">Download</button>
  <div class="side-widget">
  <a class="site-link" href="https://www.jeitler.cc" target="_blank" rel="noopener">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <ellipse cx="12" cy="16.5" rx="5.4" ry="4.3"/>
      <ellipse cx="5.2" cy="10.5" rx="2.5" ry="3.1"/>
      <ellipse cx="18.8" cy="10.5" rx="2.5" ry="3.1"/>
      <ellipse cx="8.9" cy="5.6" rx="2.4" ry="3.1"/>
      <ellipse cx="15.1" cy="5.6" rx="2.4" ry="3.1"/>
    </svg>
    www.jeitler.cc
    <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <ellipse cx="12" cy="16.5" rx="5.4" ry="4.3"/>
      <ellipse cx="5.2" cy="10.5" rx="2.5" ry="3.1"/>
      <ellipse cx="18.8" cy="10.5" rx="2.5" ry="3.1"/>
      <ellipse cx="8.9" cy="5.6" rx="2.4" ry="3.1"/>
      <ellipse cx="15.1" cy="5.6" rx="2.4" ry="3.1"/>
    </svg>
  </a>
  </div>
</div>

<div class="bucket comments collapsed" id="bucket-comments">
  <h3>
    <span class="bucket-toggle" onclick="toggleBucket('comments')">
      <span class="bucket-chevron">&#9662;</span><span>Comments ({len(comments)})</span>
    </span>
  </h3>
  <div class="bucket-body">
    {comment_rows_html}
  </div>
</div>

<div class="bucket hostlist" id="bucket-hostlist">
  <h3>
    <span class="bucket-toggle" onclick="toggleBucket('hostlist')">
      <span class="bucket-chevron">&#9662;</span><span>Host List</span>
    </span>
    <span class="bucket-actions"><span id="hostlistCount">0</span>
      <button class="dl-btn" onclick="downloadHostListCsv()"
              title="download the shown host list as CSV">&#8681; Download</button>
      <button class="dl-btn" onclick="copyBucketList(CURRENT_FILTERED, this)"
              title="copy hostnames/IPs of the shown list to clipboard">Copy</button></span>
  </h3>
  <div class="bucket-body">
    <div class="tbl-wrap">
    <table id="mainTable">
    <thead>
    <tr>
      <th onclick="sortBy('name', event)"    data-col="name"
          title="Click to sort - Shift+click to add as secondary/tertiary sort criterion">HOST</th>
      <th onclick="sortBy('state', event)"   data-col="state" style="text-align:center;width:1px;white-space:nowrap"
          title="Click to sort - Shift+click to add as secondary/tertiary sort criterion">STATE</th>
      <th style="width:220px">TIMELINE</th>
      <th onclick="sortBy('uptime', event)"  data-col="uptime" style="text-align:right"
          title="Click to sort - Shift+click to add as secondary/tertiary sort criterion">UPTIME</th>
      <th onclick="sortBy('rtt_avg', event)" data-col="rtt_avg" style="text-align:right"
          title="Click to sort - Shift+click to add as secondary/tertiary sort criterion">AVG RTT</th>
      <th onclick="sortBy('rtt_min', event)" data-col="rtt_min" style="text-align:right"
          title="Click to sort - Shift+click to add as secondary/tertiary sort criterion">MIN RTT</th>
      <th onclick="sortBy('rtt_max', event)" data-col="rtt_max" style="text-align:right"
          title="Click to sort - Shift+click to add as secondary/tertiary sort criterion">MAX RTT</th>
      <th onclick="sortBy('changes', event)" data-col="changes" style="text-align:center"
          title="Click to sort - Shift+click to add as secondary/tertiary sort criterion">CHANGES</th>
    </tr>
    </thead>
    <tbody id="tbody"></tbody>
    </table>
    </div>
  </div>
</div>

<div class="buckets" id="buckets"></div>

<div class="bucket info collapsed" id="bucket-info">
  <h3>
    <span class="bucket-toggle" onclick="toggleBucket('info')">
      <span class="bucket-chevron">&#9662;</span><span>Info ({len(infos)})</span>
    </span>
  </h3>
  <div class="bucket-body">
    {info_rows_html}
  </div>
</div>

<footer>
  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <ellipse cx="12" cy="16.5" rx="5.4" ry="4.3"/>
    <ellipse cx="5.2" cy="10.5" rx="2.5" ry="3.1"/>
    <ellipse cx="18.8" cy="10.5" rx="2.5" ry="3.1"/>
    <ellipse cx="8.9" cy="5.6" rx="2.4" ry="3.1"/>
    <ellipse cx="15.1" cy="5.6" rx="2.4" ry="3.1"/>
  </svg>
  <span>epinga.py v{VERSION} &nbsp;·&nbsp;
  &copy; Ewald Jeitler &nbsp;·&nbsp;
  supervised by <a href="https://jeitler.cc/nelly/" target="_blank" rel="noopener">Nelly</a> &nbsp;·&nbsp;
  <a href="https://tools.jeitler.cc" target="_blank" rel="noopener">tools.jeitler.cc</a> &nbsp;·&nbsp;
  <a href="https://www.jeitler.cc" target="_blank" rel="noopener">www.jeitler.cc</a></span>
  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <ellipse cx="12" cy="16.5" rx="5.4" ry="4.3"/>
    <ellipse cx="5.2" cy="10.5" rx="2.5" ry="3.1"/>
    <ellipse cx="18.8" cy="10.5" rx="2.5" ry="3.1"/>
    <ellipse cx="8.9" cy="5.6" rx="2.4" ry="3.1"/>
    <ellipse cx="15.1" cy="5.6" rx="2.4" ry="3.1"/>
  </svg>
</footer>

<script>
const MAIN = {json_data};
const VARIANTS = {variants_json};   // one dataset per SOURCE (only if the log holds several)
const SRC_SEL = (function() {{
  const m = location.hash.match(/^#src=(.*)$/);
  try {{ return m ? decodeURIComponent(m[1]) : ''; }} catch (e) {{ return ''; }}
}})();
const RAW = (function() {{
  const v = VARIANTS.find(x => x.source === SRC_SEL);
  return v ? Object.assign({{}}, MAIN, v) : MAIN;
}})();
function switchSource(v) {{
  location.hash = v ? '#src=' + encodeURIComponent(v) : '';
  location.reload();
}}

// IP-named hosts that are ALSO monitored under a hostname pointing at the same IP -
// these are the duplicates hidden in 'Hostnames' dedup mode. A raw-IP host with no
// hostname counterpart stays visible in either mode.
const REDUNDANT_IPS = new Set(
  RAW.hosts.filter(h => !isIpHost(h.name) && h.ip).map(h => h.ip)
);
// hostnames that are ALSO monitored as a raw IP host pointing at the same address -
// these are the duplicates hidden in 'IPs' dedup mode.
const IP_HOSTS_PRESENT = new Set(RAW.hosts.filter(h => isIpHost(h.name)).map(h => h.name));
const REDUNDANT_NAMES = new Set(
  RAW.hosts.filter(h => !isIpHost(h.name) && h.ip && IP_HOSTS_PRESENT.has(h.ip)).map(h => h.name)
);

// ── theme ──────────────────────────────────────────────────────────────────
(function() {{
  const saved = localStorage.getItem('epinga-theme');
  if (saved === 'light') document.documentElement.classList.add('light');
}})();
function toggleTheme() {{
  const isLight = document.documentElement.classList.toggle('light');
  localStorage.setItem('epinga-theme', isLight ? 'light' : 'dark');
  document.getElementById('themeBtn').textContent = isLight ? '🌙 Dark' : '☀ Light';
}}
// set button label on load
document.addEventListener('DOMContentLoaded', function() {{
  const isLight = document.documentElement.classList.contains('light');
  document.getElementById('themeBtn').textContent = isLight ? '🌙 Dark' : '☀ Light';
}});

let sortChain = [];   // [{{col, asc}}, ...] - earlier entries take priority, Shift+click appends
let rows = [...RAW.hosts];

const G_START = RAW.global_start ? new Date(RAW.global_start.replace(' ','T')).getTime() : 0;
const G_END   = RAW.global_end   ? new Date(RAW.global_end.replace(' ','T')).getTime()   : 1;
const G_SPAN  = G_END - G_START || 1;

function buildTimeline(h) {{
  const hStart = new Date(h.first_ts.replace(' ','T')).getTime();
  const hEnd   = new Date(h.last_ts.replace(' ','T')).getTime();

  // build state segments
  const segs = [];
  let t     = hStart;
  let state = h.initial_state;
  for (const ev of h.events) {{
    const evT = new Date(ev.ts.replace(' ','T')).getTime();
    if (evT > t) segs.push({{start: t, end: evT, state}});
    state = ev.to;
    t = evT;
  }}
  if (hEnd > t) segs.push({{start: t, end: hEnd, state}});

  // --source: periods of other sources are not drawn
  let draw = segs;
  if (h.gaps && h.gaps.length) {{
    draw = [];
    const gp = h.gaps.map(g => [new Date(g[0].replace(' ','T')).getTime(), new Date(g[1].replace(' ','T')).getTime()]);
    for (const sg of segs) {{
      let parts = [[sg.start, sg.end]];
      for (const g of gp) {{
        const nx = [];
        for (const p of parts) {{
          if (g[1] <= p[0] || g[0] >= p[1]) {{ nx.push(p); continue; }}
          if (g[0] > p[0]) nx.push([p[0], g[0]]);
          if (g[1] < p[1]) nx.push([g[1], p[1]]);
        }}
        parts = nx;
      }}
      for (const p of parts) draw.push({{start: p[0], end: p[1], state: sg.state}});
    }}
  }}

  // blank prefix/suffix (host not yet / no longer monitored)
  const preW  = ((hStart - G_START) / G_SPAN * 100).toFixed(3);
  const postW = ((G_END   - hEnd)   / G_SPAN * 100).toFixed(3);

  const segHtml = draw.map(seg => {{
    const l = ((seg.start - G_START) / G_SPAN * 100).toFixed(3);
    const w = ((seg.end   - seg.start) / G_SPAN * 100).toFixed(3);
    const c = seg.state === 'UP' ? '#3fb950'
            : seg.state === 'NO-DNS' ? '#d29922' : '#f85149';
    return `<div style="position:absolute;left:${{l}}%;width:${{w}}%;height:100%;background:${{c}}"></div>`;
  }}).join('');

  return `<div style="position:relative;width:100%;height:10px;background:var(--bg3);
    border-radius:4px;overflow:hidden" title="${{escHtml(h.first_ts)}} → ${{escHtml(h.last_ts)}}">${{segHtml}}</div>`;
}}

function stateBadge(s, changes) {{
  const label = changes > 0 ? 'FLAPPING' : s;
  return `<span class="badge ${{escHtml(label)}}">${{escHtml(label)}}</span>`;
}}

function uptimeBar(pct, flapping) {{
  const cls = flapping ? 'pct-orange' : pct >= 99 ? 'pct-green' : pct >= 90 ? 'pct-orange' : 'pct-red';
  return `<span class="${{cls}}">${{pct.toFixed(2)}} %</span>`;
}}

function rttCell(v) {{
  return v !== null ? v.toFixed(2) + ' ms' : '<span style="color:var(--dim)">–</span>';
}}

function renderTable(data) {{
  const tbody = document.getElementById('tbody');
  tbody.innerHTML = '';
  data.forEach((h, idx) => {{
    const noc_col = h.changes > 0 ? 'color:var(--orange)' : 'color:var(--dim)';
    const tr = document.createElement('tr');
    tr.id = 'r' + idx;
    tr.dataset.idx = idx;
    tr.innerHTML = `
      <td class="host">${{escHtml(hostLabel(h))}}${{ secondaryLabel(h) ? ` <span class="host-ip">| ${{escHtml(secondaryLabel(h))}}</span>` : '' }} <span class="chevron">&#8964;</span></td>
      <td style="text-align:center;white-space:nowrap">${{stateBadge(h.state, h.changes)}}</td>
      <td style="padding:0 12px"><div style="width:200px">${{buildTimeline(h)}}</div></td>
      <td style="text-align:right">${{uptimeBar(h.uptime, h.changes > 0)}}</td>
      <td style="text-align:right">${{rttCell(h.rtt_avg)}}</td>
      <td style="text-align:right">${{rttCell(h.rtt_min)}}</td>
      <td style="text-align:right">${{rttCell(h.rtt_max)}}</td>
      <td style="${{noc_col}};text-align:center">${{h.changes}}</td>`;
    tr.onclick = () => toggleDetail(tr, h);
    tbody.appendChild(tr);

    const dtr = document.createElement('tr');
    dtr.className = 'detail-row hidden';
    dtr.id = 'd' + idx;
    dtr.innerHTML = `<td colspan="8"><div class="detail-inner">${{buildDetail(h)}}</div></td>`;
    tbody.appendChild(dtr);
  }});
}}

function escHtml(s) {{
  return String(s).replace(/[&<>"']/g, c => ({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}})[c]);
}}

// RAW.comments is sorted by ts (epinga sorts before embedding) - binary search the
// [first_ts, last_ts] window instead of scanning every comment for every host row
function lowerBound(arr, ts) {{
  let lo = 0, hi = arr.length;
  while (lo < hi) {{ const mid = (lo + hi) >> 1; if (arr[mid].ts < ts) lo = mid + 1; else hi = mid; }}
  return lo;
}}
function upperBound(arr, ts) {{
  let lo = 0, hi = arr.length;
  while (lo < hi) {{ const mid = (lo + hi) >> 1; if (arr[mid].ts <= ts) lo = mid + 1; else hi = mid; }}
  return lo;
}}
function buildDetail(h) {{
  // comments are a global timeline, not per-host - only show ones logged while
  // this host was actually being observed (its first_ts..last_ts window)
  const allC = RAW.comments || [];
  const cFrom = h.first_ts ? lowerBound(allC, h.first_ts) : 0;
  const cTo   = h.last_ts  ? upperBound(allC, h.last_ts)  : allC.length;
  const relevantComments = allC.slice(cFrom, cTo);
  const timeline = [
    ...h.events.map(e => ({{ts: e.ts, kind: 'change', frm: e.frm, to: e.to}})),
    ...relevantComments.map(c => ({{ts: c.ts, kind: 'comment', text: c.text}})),
  ].sort((a, b) => a.ts < b.ts ? -1 : (a.ts > b.ts ? 1 : (a.kind === b.kind ? 0 : (a.kind === 'comment' ? -1 : 1))));
  // same second: the comment first - eping writes SOURCE SWITCH / JUMPHOST comments before the
  // result rows of the round they cause, so the cause must not be listed after its effect

  const eventsHtml = timeline.length === 0
    ? '<span style="color:var(--dim)">no state changes</span>'
    : timeline.map(e => {{
        if (e.kind === 'comment') {{
          return `<div class="event comment-event">
            <span class="ts">${{escHtml(e.ts)}}</span>
            <span class="comment-marker">&#128172;</span>
            <span class="comment-event-text">${{escHtml(e.text)}}</span>
          </div>`;
        }}
        const fc = e.frm === 'UP' ? 'var(--green)' : 'var(--red)';
        const tc = e.to  === 'UP' ? 'var(--green)' : 'var(--red)';
        return `<div class="event">
          <span class="ts">${{escHtml(e.ts)}}</span>
          <span style="color:${{fc}}">${{escHtml(e.frm)}}</span>
          <span class="arrow">→</span>
          <span style="color:${{tc}}">${{escHtml(e.to)}}</span>
        </div>`;
      }}).join('');

  const rttHtml = h.rtt_avg !== null
    ? `<div class="kv"><span class="k">Min</span><span class="v">${{h.rtt_min.toFixed(2)}} ms</span></div>
       <div class="kv"><span class="k">Max</span><span class="v">${{h.rtt_max.toFixed(2)}} ms</span></div>
       <div class="kv"><span class="k">Avg</span><span class="v">${{h.rtt_avg.toFixed(2)}} ms</span></div>
       <div class="kv"><span class="k">Samples</span><span class="v">${{h.rtt_cnt}}</span></div>`
    : '<span style="color:var(--dim)">no RTT data</span>';

  return `<div class="detail-grid">
    <div class="detail-section">
      <h4>STATE CHANGES</h4>
      <div class="events">${{eventsHtml}}</div>
    </div>
    <div class="detail-section">
      <h4>STATISTICS</h4>
      <div class="stat-list">
        <div class="kv"><span class="k">Ip</span><span class="v">${{escHtml(h.ip || h.name)}}</span></div>
        ${{[['inv_name', 'Name'], ['serial', 'Serial'], ['model', 'Model'], ['location', 'Location'], ['sysloc', 'sysLocation'], ['type', 'Type'], ['comment', 'Comment']]
            .filter(([k]) => h[k]).map(([k, l]) => `<div class="kv"><span class="k">${{l}}</span><span class="v">${{escHtml(h[k])}}</span></div>`).join('')}}
        <div class="kv"><span class="k">Uptime</span><span class="v">${{escHtml(h.time_up)}}</span></div>
        <div class="kv"><span class="k">Downtime</span><span class="v">${{escHtml(h.time_down)}}</span></div>
        <div class="kv"><span class="k">Total span</span><span class="v">${{escHtml(h.span)}}</span></div>
        <div class="kv"><span class="k">First seen</span><span class="v">${{escHtml(h.first_ts)}}</span></div>
        <div class="kv"><span class="k">Last seen</span><span class="v">${{escHtml(h.last_ts)}}</span></div>
        ${{rttHtml}}
      </div>
    </div>
  </div>`;
}}

function toggleDetail(tr, h) {{
  const idx = tr.dataset.idx;
  const dtr = document.getElementById('d' + idx);
  const expanded = !dtr.classList.contains('hidden');
  // close all
  document.querySelectorAll('.detail-row').forEach(r => r.classList.add('hidden'));
  document.querySelectorAll('tbody tr:not(.detail-row)').forEach(r => r.classList.remove('expanded'));
  if (!expanded) {{
    dtr.classList.remove('hidden');
    tr.classList.add('expanded');
  }}
}}

// updates header arrows/order badges to match the current sortChain
function updateSortHeaders() {{
  document.querySelectorAll('thead th[data-col]').forEach(th => {{
    th.classList.remove('sort-asc','sort-desc');
    const old = th.querySelector('.sort-num');
    if (old) old.remove();
    const idx = sortChain.findIndex(s => s.col === th.dataset.col);
    if (idx !== -1) {{
      th.classList.add(sortChain[idx].asc ? 'sort-asc' : 'sort-desc');
      if (sortChain.length > 1) {{
        const badge = document.createElement('span');
        badge.className = 'sort-num';
        badge.textContent = String(idx + 1);
        th.appendChild(badge);
      }}
    }}
  }});
  const sel = document.getElementById('sortSel');
  sel.value = (sortChain.length === 1) ? sortChain[0].col : '';
  sel.title = sortChain.length > 1
    ? 'Multi-column sort active - see column headers (Shift+click a header to add/remove it)'
    : '';
}}

// plain click: sort by only this column (toggles direction if it's already the
// sole criterion). Shift+click: append this column as an additional tie-breaker,
// or toggle its direction if it's already part of the chain
function sortBy(col, ev) {{
  const shift = !!(ev && ev.shiftKey);
  const idx = sortChain.findIndex(s => s.col === col);
  if (shift) {{
    if (idx !== -1) {{
      sortChain[idx].asc = !sortChain[idx].asc;
    }} else {{
      sortChain.push({{col, asc: true}});
    }}
  }} else {{
    if (idx === 0 && sortChain.length === 1) {{
      sortChain[0].asc = !sortChain[0].asc;
    }} else {{
      sortChain = [{{col, asc: true}}];
    }}
  }}
  updateSortHeaders();
  applyFilter();
}}

function sortBySelect() {{
  const v = document.getElementById('sortSel').value;
  sortChain = v ? [{{col: v, asc: true}}] : [];
  updateSortHeaders();
  applyFilter();
}}

let dedupMode = '';   // '': off (default), 'name': show hostname (hide its IP counterpart), 'ip': show IP (hide its hostname counterpart)
let showIp     = false;   // display toggle only - which of name/ip is the primary label, independent of dedupMode

function isIpHost(name) {{
  if (/^(\\d{{1,3}}\\.){{3}}\\d{{1,3}}$/.test(name)) return true;
  return name.indexOf(':') !== -1 && /^[0-9a-fA-F:]+$/.test(name);   // IPv6 literal
}}

// IPv4 dotted-quad -> a comparable integer, or null if not a valid IPv4 literal
// (any octet > 255) - used so host/IP columns sort numerically (172.17.17.9
// before .10) instead of lexicographically (.10 before .9, .100 before .11).
function ipv4ToNum(s) {{
  const m = /^(\\d{{1,3}})\\.(\\d{{1,3}})\\.(\\d{{1,3}})\\.(\\d{{1,3}})$/.exec(s);
  if (!m) return null;
  const o = [1, 2, 3, 4].map(i => Number(m[i]));
  if (o.some(n => n > 255)) return null;
  return ((o[0] * 256 + o[1]) * 256 + o[2]) * 256 + o[3];
}}

// comparator for any host-identifying string (a 'name' or an IP, whichever is
// shown - see hostLabel()): numeric for two IPv4 literals, otherwise plain
// text order (IPv6 literals and hostnames alike - no numeric ordering defined
// for those here).
function hostCompare(a, b) {{
  const na = ipv4ToNum(a), nb = ipv4ToNum(b);
  if (na !== null && nb !== null) return na - nb;
  if (na !== null) return -1;   // IPv4 addresses sort before hostnames/IPv6
  if (nb !== null) return 1;
  return a.localeCompare(b);
}}

// true if 'h' is the duplicate side that the current dedup mode should hide -
// applied to both the table filter and the bucket sections below
function isDeduped(h) {{
  if (dedupMode === 'name') return isIpHost(h.name) && REDUNDANT_IPS.has(h.name);
  if (dedupMode === 'ip')   return !isIpHost(h.name) && REDUNDANT_NAMES.has(h.name);
  return false;   // '' = no deduplication
}}

// primary label for a host row/tag - IP when 'IP View' is on and an ip is known,
// hostname otherwise; applied everywhere a host is displayed (table + all buckets)
function hostLabel(h) {{
  return (showIp && h.ip) ? h.ip : h.name;
}}

// the "other" value next to the primary label (e.g. the small "| 1.2.3.4" suffix),
// or null when there is none / it equals the primary
function secondaryLabel(h) {{
  const primary = hostLabel(h);
  if (h.ip && h.ip !== primary) return h.ip;
  if (h.name !== primary) return h.name;
  return null;
}}

// display-only toggle: switches every host's primary label between name and IP
function toggleShowIp() {{
  showIp = !showIp;
  document.getElementById('btnShowIp').classList.toggle('active', showIp);
  applyFilter();
  renderBuckets();
}}

// total hosts involved in a duplicate hostname/IP pair - both sides count,
// independent of dedupMode (mirrors count_duplicate_hosts() server-side, used
// for the initial DUPLICATES card before any JS has run)
function isDuplicatePair(h) {{
  if (isIpHost(h.name)) return REDUNDANT_IPS.has(h.name);
  return !!(h.ip && REDUNDANT_NAMES.has(h.name));
}}

// TOTAL/UP/FLAPPING/DOWN/NO-DNS must reflect the active dedup mode (a hidden
// duplicate should not still count towards the totals) - DUPLICATES itself
// stays constant, it reports what's in the data, not what the filter is doing
function updateCards() {{
  const active = RAW.hosts.filter(h => !isDeduped(h));
  const nTotal = active.length;
  const nUp    = active.filter(h => h.changes === 0 && h.state === 'UP').length;
  const nFlap  = active.filter(h => h.changes > 0).length;
  const nDown  = active.filter(h => h.changes === 0 && h.state === 'DOWN').length;
  const nNodns = active.filter(h => h.changes === 0 && h.state === 'NO-DNS').length;
  document.querySelector('#cardTotal .num').textContent = nTotal;
  document.querySelector('#cardUp .num').textContent    = nUp;
  document.querySelector('#cardFlap .num').textContent  = nFlap;
  document.querySelector('#cardDown .num').textContent  = nDown;
  document.querySelector('#cardNodns .num').textContent = nNodns;
  // dedup on -> the redundant side of every pair is hidden, so none of what's
  // left counts as a duplicate anymore; a '0' there reads as 'no problem found'
  // which is misleading while dedup is hiding the very thing it would count,
  // so show an active-state message instead, same card size either way
  const dupCard = document.getElementById('cardDup');
  if (dedupMode === '') {{
    const nDup = RAW.hosts.filter(isDuplicatePair).length;
    dupCard.innerHTML = '<div class="num">' + nDup + '</div><div class="lbl">DUPLICATES</div>';
  }} else {{
    const nFiltered = RAW.hosts.filter(isDeduped).length;
    dupCard.innerHTML = '<div class="info">DEDUPLICATION<br>ACTIVE</div>' +
      '<div class="info-sub">' + nFiltered + ' FILTERED</div>';
  }}
}}

function onDedupSelectChange() {{
  dedupMode = document.getElementById('dedupSel').value;
  applyFilter();
  renderBuckets();
  updateCards();
}}

// saves this report as a standalone .html file - the whole page (current DOM,
// so theme/dedup/sort/collapse state as currently shown) is self-contained
// already (CSS/JS/data all inlined), so a plain Blob download of outerHTML
// reproduces it exactly, same filename convention as --html/epinga.py itself
function downloadHtml() {{
  syncMetaSelected();
  const blob = new Blob(['<!DOCTYPE html>\\n' + document.documentElement.outerHTML], {{type: 'text/html'}});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url;
  a.download = (RAW.base || 'epinga') + '_report.html';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}}
// single-column comparator used by the sortChain - 'state' groups by the
// UP/FLAPPING/DOWN/NO-DNS badge order (not the raw state string, which has no
// FLAPPING value); missing values (null) always sort last regardless of direction
function compareOneColumn(col, asc, a, b) {{
  if (col === 'state') {{
    const od = stateOrder(a) - stateOrder(b);
    if (od !== 0) return asc ? od : -od;
    return asc ? hostCompare(a.name, b.name) : hostCompare(b.name, a.name);
  }}
  if (col === 'name') {{
    return asc ? hostCompare(a.name, b.name) : hostCompare(b.name, a.name);
  }}
  const av = a[col], bv = b[col];
  const aNull = av === null, bNull = bv === null;
  if (aNull || bNull) {{
    if (aNull && bNull) return 0;
    return aNull ? 1 : -1;
  }}
  if (typeof av === 'string') return asc ? av.localeCompare(bv) : bv.localeCompare(av);
  return asc ? av - bv : bv - av;
}}

// current filtered+sorted host list, kept in sync by applyFilter() - backs
// the Host List section's Download / Copy buttons (bucket buttons instead
// take their own bucket's list directly, since those are fixed subsets)
let CURRENT_FILTERED = [];

// inventory columns (eping.py 3.62+ logs): one drop-down per column that has any
// value in this log, listing its distinct values (with host counts)
const NONE_VAL = '\u0001none';
const META_SEARCH = ['inv_name', 'serial', 'model', 'location', 'sysloc', 'type', 'comment'];
const META_FILTERS = [
  {{key: 'model',    label: 'Model'}},
  {{key: 'location', label: 'Location'}},
  {{key: 'sysloc',   label: 'sysLocation'}},
  {{key: 'type',     label: 'Type'}},
  {{key: 'comment',  label: 'Comment'}},
].filter(f => RAW.hosts.some(h => h[f.key]));
// the options of each drop-down only list what exists among the hosts that pass the OTHER
// inventory drop-downs, with matching host counts (e.g. Model = X: Location lists only
// the locations that have model X). `cur` = selection to keep (default: the live one).
function fillMetaOptions(cur) {{
  if (!cur) {{
    cur = {{}};
    META_FILTERS.forEach(f => {{ cur[f.key] = document.getElementById('mf_' + f.key).value; }});
  }}
  META_FILTERS.forEach(f => {{
    const others = META_FILTERS.filter(g => g.key !== f.key && cur[g.key]);
    const counts = new Map();
    let nNone = 0;
    RAW.hosts.forEach(h => {{
      for (const g of others) {{
        const v = cur[g.key];
        if (v === NONE_VAL ? !!h[g.key] : h[g.key] !== v) return;
      }}
      if (h[f.key]) counts.set(h[f.key], (counts.get(h[f.key]) || 0) + 1); else nNone++;
    }});
    const sel = document.getElementById('mf_' + f.key);
    sel.innerHTML = '';
    const add = (val, text) => {{ const o = document.createElement('option'); o.value = val; o.textContent = text; sel.appendChild(o); }};
    add('', 'ALL');
    [...counts.keys()].sort((a, b) => a.localeCompare(b, undefined, {{numeric: true}}))
      .forEach(v => add(v, v + '  (' + counts.get(v) + ')'));
    if (nNone) add(NONE_VAL, '(empty)  (' + nNone + ')');
    const want = cur[f.key];
    if (want && ![...sel.options].some(o => o.value === want)) add(want, (want === NONE_VAL ? '(empty)' : want) + '  (0)');
    sel.value = want || '';
  }});
}}
function initMetaFilters() {{
  const box = document.getElementById('metaFilters');
  // a saved copy of this report (Download) keeps its selection as `selected` options
  const prev = {{}};
  META_FILTERS.forEach(f => {{ const old = document.getElementById('mf_' + f.key); if (old) prev[f.key] = old.value; }});
  box.innerHTML = '';
  META_FILTERS.forEach(f => {{
    const grp = document.createElement('div');
    grp.className = 'mf';
    const lab = document.createElement('label');
    lab.textContent = f.label;
    lab.htmlFor = 'mf_' + f.key;
    const sel = document.createElement('select');
    sel.id = 'mf_' + f.key;
    sel.title = 'show only hosts with this ' + f.label;
    sel.onchange = () => {{ fillMetaOptions(); applyFilter(); }};
    grp.appendChild(lab);
    grp.appendChild(sel);
    box.appendChild(grp);
  }});
  const cur = {{}};
  META_FILTERS.forEach(f => {{ cur[f.key] = prev[f.key] || ''; }});
  fillMetaOptions(cur);
}}
// Reset: text filter, Show selection and every inventory drop-down back to 'all'
// (sort order, IP View and deduplication are display modes, not filters - left alone)
function resetFilters() {{
  document.getElementById('search').value = '';
  document.getElementById('stateFilter').value = '';
  META_FILTERS.forEach(f => {{ document.getElementById('mf_' + f.key).value = ''; }});
  fillMetaOptions();
  applyFilter();
}}
function syncMetaSelected() {{
  META_FILTERS.forEach(f => {{
    const sel = document.getElementById('mf_' + f.key);
    if (sel) [...sel.options].forEach(o => o.toggleAttribute('selected', o.value === sel.value));
  }});
}}
function applyFilter() {{
  const qRaw  = document.getElementById('search').value;
  const state = document.getElementById('stateFilter').value;
  const searchEl = document.getElementById('search');
  // plain text is used as a substring match (old behaviour, unaffected); anything
  // that does not parse as valid regex syntax just falls back to substring too, so
  // typing a literal '(' or similar never surprises a user who didn't mean regex -
  // only used when the text actually compiles as a RegExp
  let qRe = null, qInvalid = false;
  if (qRaw) {{
    try {{ qRe = new RegExp(qRaw, 'i'); }}
    catch (e) {{ qInvalid = true; }}
  }}
  searchEl.classList.toggle('invalid', qInvalid);
  const metaSel = META_FILTERS.map(f => [f.key, document.getElementById('mf_' + f.key).value]).filter(x => x[1] !== '');
  let filtered = RAW.hosts.filter(h => {{
    for (const [k, v] of metaSel) {{
      if (v === NONE_VAL ? !!h[k] : h[k] !== v) return false;
    }}
    if (qRaw) {{
      const fields = [h.name, h.ip, ...META_SEARCH.map(k => h[k])].filter(Boolean);
      if (qInvalid) {{
        const q = qRaw.toLowerCase();
        if (!fields.some(f => f.toLowerCase().includes(q))) return false;
      }} else if (!fields.some(f => qRe.test(f))) {{
        return false;
      }}
    }}
    // mirrors eping.py's live view-filter set (WEB_VIEW_MODES), minus
    // CURRENTLY-UP/CURRENTLY-DOWN (no meaning for a static log) and EVER-UP
    // (redundant with UP+FLAPPING here: changes>0 already implies it passed
    // through UP at some point): ALWAYS-UP/-DOWN/NO-DNS = current state never
    // changed (changes===0, same as the summary buckets above);
    // UP+FLAPPING/DOWN+FLAPPING = currently in that state OR ever flapped -
    // kept disjoint from NO-DNS, which stays its own category rather than
    // folding into "down".
    switch (state) {{
      case '':            break;
      case 'ALWAYS-UP':   if (h.state !== 'UP'     || h.changes > 0) return false; break;
      case 'ALWAYS-DOWN': if (h.state !== 'DOWN'   || h.changes > 0) return false; break;
      case 'NO-DNS':      if (h.state !== 'NO-DNS' || h.changes > 0) return false; break;
      case 'FLAP':        if (h.changes === 0) return false; break;
      case 'UP+FLAP':     if (!(h.state === 'UP'   || h.changes > 0)) return false; break;
      case 'DOWN+FLAP':   if (!(h.state === 'DOWN' || h.changes > 0)) return false; break;
    }}
    if (isDeduped(h)) return false;
    return true;
  }});
  filtered.sort((a, b) => {{
    for (const {{col, asc}} of sortChain) {{
      const c = compareOneColumn(col, asc, a, b);
      if (c !== 0) return c;
    }}
    if (sortChain.length === 0) {{
      // default: UP → FLAPPING → DOWN → NO-DNS, then by name
      const od = stateOrder(a) - stateOrder(b);
      return od !== 0 ? od : hostCompare(a.name, b.name);
    }}
    return 0;   // every criterion in the chain tied
  }});
  document.getElementById('shownHosts').textContent = filtered.length + ' shown';
  CURRENT_FILTERED = filtered;
  document.getElementById('hostlistCount').textContent = filtered.length;
  renderTable(filtered);
}}

// ── buckets ────────────────────────────────────────────────────────────────
// download this bucket's hostnames/IPs as a .txt file, one per line - named after
// the source logfile so it lines up with eping-log_<ts>[.csv], e.g.
// eping-log_2026-09-05_16:50:05-up-hosts.txt
function downloadBucketList(list, suffix) {{
  const names = list.map(h => hostLabel(h));
  const blob  = new Blob([names.join('\\n') + (names.length ? '\\n' : '')], {{type: 'text/plain'}});
  const url   = URL.createObjectURL(blob);
  const a     = document.createElement('a');
  a.href      = url;
  a.download  = (RAW.base || 'epinga-export') + '-' + suffix + '-hosts.txt';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}}

// CSV export of the Host List section, honouring the active search/state
// filter and dedup mode (same set CURRENT_FILTERED/the table itself shows) -
// unlike downloadBucketList() below (plain hostname/IP .txt for the fixed
// bucket subsets), this carries the full per-host stats as real CSV columns.
function csvField(v) {{
  const s = v === null || v === undefined ? '' : String(v);
  return /[",\\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}}
function downloadHostListCsv() {{
  const cols = ['name', 'ip', 'state', 'uptime', 'rtt_avg', 'rtt_min', 'rtt_max', 'changes'];
  const header = ['HOST', 'IP', 'STATE', 'UPTIME_PCT', 'AVG_RTT', 'MIN_RTT', 'MAX_RTT', 'CHANGES'];
  if (META_FILTERS.length || RAW.hosts.some(h => h.serial || h.inv_name)) {{   // inventory columns, if the log has them
    cols.push(...META_SEARCH);
    header.push('INV_HOSTNAME', 'SERIAL_NUMBER', 'MODEL', 'LOCATION', 'SYSLOCATION', 'TYPE', 'INV_COMMENT');
  }}
  const lines  = [header.join(',')];
  CURRENT_FILTERED.forEach(h => {{
    lines.push(cols.map(c => csvField(h[c])).join(','));
  }});
  const blob = new Blob([lines.join('\\n') + '\\n'], {{type: 'text/csv'}});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = (RAW.base || 'epinga-export') + '-hostlist.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}}

function fallbackCopy(text, done) {{
  // execCommand fallback: works on file:// pages where the async Clipboard API may be unavailable
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity  = '0';
  document.body.appendChild(ta);
  ta.select();
  let ok = false;
  try {{ ok = document.execCommand('copy'); }} catch (e) {{ ok = false; }}
  document.body.removeChild(ta);
  done(ok);
}}

function copyBucketList(list, btn) {{
  const names = list.map(h => hostLabel(h));
  const text  = names.join('\\n') + (names.length ? '\\n' : '');
  function done(ok) {{
    if (!btn) return;
    const orig = btn.textContent;
    btn.textContent = ok ? 'Copied!' : 'Copy failed';
    setTimeout(() => {{ btn.textContent = orig; }}, 1200);
  }}
  if (navigator.clipboard && navigator.clipboard.writeText) {{
    navigator.clipboard.writeText(text).then(() => done(true)).catch(() => fallbackCopy(text, done));
  }} else {{
    fallbackCopy(text, done);
  }}
}}

let BUCKET_LISTS = {{}};
// per-bucket sort direction ('asc'/'desc'), keyed by suffix - survives re-renders
// (showIp toggle, dedup change, collapse) since it lives outside renderBuckets().
// every bucket starts descending (Z-A / highest change-count first) until the
// user clicks its sort arrow to flip it.
let BUCKET_SORT = {{}};
function bucketSortDir(suffix) {{
  return BUCKET_SORT[suffix] || 'desc';
}}
function toggleBucketSort(suffix, evt) {{
  if (evt) evt.stopPropagation();   // don't also collapse the bucket
  BUCKET_SORT[suffix] = bucketSortDir(suffix) === 'asc' ? 'desc' : 'asc';
  renderBuckets();
}}
function downloadBucket(suffix) {{
  downloadBucketList(BUCKET_LISTS[suffix] || [], suffix);
}}
function copyBucket(suffix, btn) {{
  copyBucketList(BUCKET_LISTS[suffix] || [], btn);
}}

function renderBuckets() {{
  const pool = RAW.hosts.filter(h => !isDeduped(h));

  // 'up'/'down'/'nodns' sort alphabetically by the currently shown label;
  // 'flap' sorts by change count (most flappy first by default) - same criterion
  // as before, just reversible now.
  function byName(lst, suffix) {{
    const dir = bucketSortDir(suffix);
    const s   = [...lst].sort((a, b) => hostCompare(hostLabel(a), hostLabel(b)));
    return dir === 'desc' ? s.reverse() : s;
  }}
  function byChanges(lst, suffix) {{
    const dir = bucketSortDir(suffix);
    const s   = [...lst].sort((a, b) => a.changes - b.changes);
    return dir === 'desc' ? s.reverse() : s;
  }}

  const up      = byName(pool.filter(h => h.changes === 0 && h.state === 'UP'), 'up');
  const upflap  = byName(pool.filter(h => h.state === 'UP'   || h.changes > 0), 'upflap');
  const flap    = byChanges(pool.filter(h => h.changes > 0), 'flap');
  const down    = byName(pool.filter(h => h.changes === 0 && h.state === 'DOWN'), 'down');
  const downflap= byName(pool.filter(h => h.state === 'DOWN' || h.changes > 0), 'downflap');
  const nodns   = byName(pool.filter(h => h.changes === 0 && h.state === 'NO-DNS'), 'nodns');

  // per-host tag colour: a flapping member is always orange regardless of
  // which bucket it's shown in (matches the dedicated Flapping bucket), a
  // non-flapping member keeps its actual current-state colour - matters for
  // the UP+FLAPPING/DOWN+FLAPPING buckets, which mix both kinds of member.
  function hostCls(h) {{
    if (h.changes > 0) return 'flap';
    if (h.state === 'UP')   return 'up';
    if (h.state === 'DOWN') return 'down';
    return 'nodns';
  }}
  function tags(lst, labelFn) {{
    if (!lst.length) return '<span style="color:var(--dim)">–</span>';
    return lst.map(h => `<span class="tag ${{hostCls(h)}}">${{labelFn(h)}}</span>`).join('');
  }}

  // members that also flapped get the same "(N)" change-count suffix as the
  // Flapping bucket - the up/down-only members among them stay plain
  const flapSuffix = h => h.changes > 0 ? ` <span class="chg">(${{h.changes}})</span>` : '';
  const bkts = [
    {{ title:'Always UP',      list:up,       suffix:'up',
       fn: h=>`${{escHtml(hostLabel(h))}}` }},
    {{ title:'UP+FLAPPING',    list:upflap,   suffix:'upflap',
       fn: h=>`${{escHtml(hostLabel(h))}}${{flapSuffix(h)}}` }},
    {{ title:'Flapping',       list:flap,     suffix:'flap',
       fn: h=>`${{escHtml(hostLabel(h))}} <span class="chg">(${{h.changes}})</span>` }},
    {{ title:'Always DOWN',    list:down,     suffix:'down',
       fn: h=>`${{escHtml(hostLabel(h))}}` }},
    {{ title:'DOWN+FLAPPING',  list:downflap, suffix:'downflap',
       fn: h=>`${{escHtml(hostLabel(h))}}${{flapSuffix(h)}}` }},
    {{ title:'No-DNS',         list:nodns,    suffix:'nodns',
       fn: h=>`${{escHtml(hostLabel(h))}}` }},
  ];
  BUCKET_LISTS = {{}};
  bkts.forEach(b => {{ BUCKET_LISTS[b.suffix] = b.list; }});
  const wasCollapsed = new Set(
    bkts.map(b => b.suffix).filter(s => {{
      const el = document.getElementById('bucket-' + s);
      // first render (el not created yet): default everything collapsed
      // except DOWN+FLAPPING - Host List stays open too, but that's a
      // separate, static bucket outside this list.
      if (!el) return s !== 'downflap';
      return el.classList.contains('collapsed');
    }})
  );
  document.getElementById('buckets').innerHTML = bkts.map(b => `
    <div class="bucket" id="bucket-${{b.suffix}}">
      <h3>
        <span class="bucket-toggle" onclick="toggleBucket('${{b.suffix}}')">
          <span class="bucket-chevron">&#9662;</span><span>${{b.title}}</span>
          <span class="sort-btn" onclick="toggleBucketSort('${{b.suffix}}', event)"
                title="click to reverse sort order">${{bucketSortDir(b.suffix) === 'asc' ? '&#9650;' : '&#9660;'}}</span>
        </span>
        <span class="bucket-actions"><span>${{b.list.length}}</span>
        <button class="dl-btn" onclick="downloadBucket('${{b.suffix}}')"
                title="download hostnames/IPs of this list as .txt"
                ${{b.list.length ? '' : 'disabled'}}>&#8681; Download</button>
        <button class="dl-btn" onclick="copyBucket('${{b.suffix}}', this)"
                title="copy hostnames/IPs of this list to clipboard"
                ${{b.list.length ? '' : 'disabled'}}>Copy</button></span>
      </h3>
      <div class="bucket-body">
        <div class="tag-list">${{tags(b.list, b.fn)}}</div>
      </div>
    </div>`).join('');
  wasCollapsed.forEach(s => {{
    const el = document.getElementById('bucket-' + s);
    if (el) el.classList.add('collapsed');
  }});
}}

function toggleBucket(suffix) {{
  const el = document.getElementById('bucket-' + suffix);
  if (el) el.classList.toggle('collapsed');
}}

function stateOrder(h) {{
  if (h.changes > 0)          return 1;  // FLAPPING
  if (h.state === 'UP')       return 0;  // always UP
  if (h.state === 'DOWN')     return 2;  // always DOWN
  return 3;                              // NO-DNS
}}
const defaultSorted = [...RAW.hosts].sort((a, b) => {{
  const od = stateOrder(a) - stateOrder(b);
  if (od !== 0) return od;
  return hostCompare(a.name, b.name);
}});
// initial render bypasses applyFilter() (no filter/search applied yet) - keep
// CURRENT_FILTERED/hostlistCount in sync here too, otherwise Download/Copy
// stay empty and the count shows 0 until the user first touches the filter
CURRENT_FILTERED = defaultSorted;
document.getElementById('hostlistCount').textContent = defaultSorted.length;
// header line and source switch follow the selected dataset
(function() {{
  document.getElementById('metaSrc').innerHTML = RAW.source
    ? 'Source: <strong>' + escHtml(RAW.source) + '</strong> &nbsp;|&nbsp; ' : '';
  document.getElementById('metaRows').textContent  = RAW.rows_read.toLocaleString('en-US');
  document.getElementById('metaHosts').textContent = RAW.hosts.length;
  document.getElementById('shownHosts').textContent = defaultSorted.length + ' shown';
  if (VARIANTS.length) {{
    const sel = document.getElementById('srcSel');
    sel.innerHTML = '<option value="">All sources (combined)</option>' + VARIANTS.map(v =>
      '<option value="' + escHtml(v.source) + '"' + (v.source === SRC_SEL ? ' selected' : '') + '>' + escHtml(v.source) + '</option>').join('');
    sel.style.display = '';
  }}
}})();
renderTable(defaultSorted);
initMetaFilters();
if (META_FILTERS.some(f => document.getElementById('mf_' + f.key).value !== '')) applyFilter();
renderBuckets();
updateCards();
// Download saves this DOM as a file - pointless (and confusing) when the report
// is already sitting on disk as a local file; only useful when served over
// HTTP (e.g. eping.py's GENERATE REPORT / /api/report), where there is no
// local copy for the user to grab otherwise.
if (location.protocol === 'file:') {{
  document.getElementById('btnDownloadHtml').style.display = 'none';
  document.getElementById('sepDownload').style.display = 'none';
}}
</script>
</body>
</html>"""
    with open(out_path, 'w', encoding='utf-8') as fh:
        fh.write(html)


# ── output capture helpers ────────────────────────────────────────────────────
ANSI_ESCAPE = re.compile(r'\x1b\[[0-9;]*[mKJ]|\r')

def strip_ansi(s):
    return ANSI_ESCAPE.sub('', s)

class _Tee:
    """Write to both the real stdout and a StringIO buffer."""
    def __init__(self, real, buf):
        self._real = real
        self._buf  = buf
    def write(self, s):
        self._real.write(s)
        self._buf.write(s)
        return len(s)
    def flush(self):
        self._real.flush()
    def __getattr__(self, name):
        return getattr(self._real, name)


def getch_prompt(html_path):
    """Print an Enter/Esc prompt and return True if Enter was pressed."""
    print(f'\n  Open HTML report?  '
          f'{col("[Enter]", CGREEN)} open   {col("[Esc]", CDIM)} skip  ',
          end='', flush=True)
    try:
        import tty, termios
        fd  = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.buffer.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        print()
        return ch in (b'\r', b'\n')
    except Exception:
        try:
            ans = input()
        except EOFError:
            print()
            return False
        return ans.strip() == ''


# ── file selection menu ───────────────────────────────────────────────────────
def fmt_size(n):
    """Human-readable file size with 2 decimal places (KB/MB/GB)."""
    if n < 1024:
        return f'{n} B'
    for unit in ('KB', 'MB', 'GB', 'TB'):
        n /= 1024
        if n < 1024:
            return f'{n:.2f} {unit}'
    return f'{n:.2f} TB'


def file_menu(ext='.csv'):
    with os.scandir() as it:
        entries = sorted(
            (f.name, f.stat().st_size)
            for f in it
            if f.is_file() and f.name.endswith(ext)
        )
    if not entries:
        die(f'No *{ext} files found in current directory.')
    size_w = max(len(fmt_size(sz)) for _, sz in entries)
    hr()
    print(f'  {"NO":>4}  {"SIZE":>{size_w}}  FILENAME')
    hr()
    for i, (name, sz) in enumerate(entries, 1):
        print(f'  {i:>4}  {fmt_size(sz):>{size_w}}  {name}')
    hr()
    files = [name for name, _ in entries]
    while True:
        choice = input(f'  Select file number (or "e" to exit): ').strip()
        if choice.lower() == 'e':
            sys.exit(0)
        if choice.isdigit() and 1 <= int(choice) <= len(files):
            return files[int(choice) - 1]
        print(f'  Invalid – enter 1..{len(files)} or e')


# ── argument parsing ──────────────────────────────────────────────────────────
def build_parser():
    p = argparse.ArgumentParser(
        description=f'epinga.py v{VERSION} – eping logfile analyser (large-file capable)',
        formatter_class=argparse.RawTextHelpFormatter
    )
    p.add_argument('-f', '--logfile',  dest='filename', default='',
                   help='CSV logfile (omit for interactive menu)')
    p.add_argument('-H', '--host',     dest='hosts', action='append', default=[],
                   metavar='HOST',
                   help='Filter: only show this host (repeatable)')
    p.add_argument('-s', '--start',    dest='ts_start', default='',
                   metavar='YYYY-MM-DD HH:MM:SS',
                   help='Only include rows from this timestamp onwards')
    p.add_argument('-e', '--end',      dest='ts_end',   default='',
                   metavar='YYYY-MM-DD HH:MM:SS',
                   help='Only include rows up to this timestamp')
    p.add_argument('-S', '--sort',      dest='sort', default='name',
                   choices=['name', 'flapping', 'uptime', 'rtt'],
                   help='Sort summary table: name | flapping | uptime | rtt  (default: name)')
    p.add_argument('--source',         dest='source', action='append', default=[], metavar='SOURCE',
                   help='Only analyse rows of this SOURCE ("local" or the jump host label, see log column SOURCE;\nrepeatable); uptime, RTT, changes and timeline cover only its periods')
    p.add_argument('--no-source-switch', dest='no_source_switch', action='store_true',
                   help='HTML report: do not embed one dataset per SOURCE (no source switch in the report;\nby default every source of a multi-source log is analysed on its own as well)')
    p.add_argument('--progress-file',  dest='progress_file', default='', metavar='FILE',
                   help='Write the progress (percent, remaining seconds, phase) as JSON to FILE - used by eping.py')
    p.add_argument('--no-detail',      dest='no_detail', action='store_true',
                   help='Skip per-host detail, show summary only')
    p.add_argument('--no-changes',     dest='no_changes', action='store_true',
                   help='Omit state-change event list per host')
    p.add_argument('--html',           dest='html_out', default='', metavar='FILE',
                   help='Custom filename for HTML report (default: auto-named)')
    p.add_argument('--open',           dest='open_browser', action='store_true',
                   help='Open HTML report automatically without asking')
    p.add_argument('--no-open',        dest='no_open', action='store_true',
                   help='Never open the report and never ask (headless/scripted runs)')
    p.add_argument('-q', '--quiet',    dest='quiet', action='store_true',
                   help='Suppress progress bar')
    p.add_argument('--no-version-check', dest='no_version_check', action='store_true',
                   help='Skip the online update check (e.g. for headless/scripted runs)')
    p.add_argument('--version',        action='version', version=f'epinga.py {VERSION}')
    return p


# ── main ──────────────────────────────────────────────────────────────────────
def _safe_stdio():
    """Never crash on non-encodable output (e.g. ASCII locale on Python 3.6,
    no PEP 538/540 coercion): keep the stream's encoding, replace what it can't encode."""
    for name in ('stdout', 'stderr'):
        st = getattr(sys, name)
        enc = (getattr(st, 'encoding', None) or 'ascii')
        if enc.lower().replace('-', '') == 'utf8' or not hasattr(st, 'buffer'):
            continue
        setattr(sys, name, io.TextIOWrapper(st.buffer, encoding=enc, errors='replace',
                                            line_buffering=True))


def main():
    signal.signal(signal.SIGINT, sigint_handler)

    if sys.version_info < (3, 6):
        die('Python 3.6 or later required.')
    _safe_stdio()

    args = build_parser().parse_args()

    # resolve filename
    filename = args.filename or file_menu()

    # parse optional filters
    filter_hosts = set(args.hosts) if args.hosts else None

    ts_start = parse_ts(args.ts_start) if args.ts_start else None
    ts_end   = parse_ts(args.ts_end)   if args.ts_end   else None
    if args.ts_start and ts_start is None:
        die(f'--start: invalid timestamp "{args.ts_start}" (expected {TS_FMT.replace("%", "")})')
    if args.ts_end and ts_end is None:
        die(f'--end: invalid timestamp "{args.ts_end}" (expected {TS_FMT.replace("%", "")})')
    if ts_start and ts_end and ts_start > ts_end:
        die('--start must not be later than --end')

    try:
        _fh, file_size = open_log_bin(filename)
        _fh.close()
    except OSError as e:
        die(str(e))

    # source filter: --source (repeatable), or a menu when the log holds several sources (interactive only)
    source = [x.strip() for x in args.source if x.strip()]
    srcs = list_sources(filename) if (source or (sys.stdin.isatty() and sys.stdout.isatty())) else []
    if not source and len(srcs) > 1 and sys.stdin.isatty() and sys.stdout.isatty():
        hr()
        print('  Sources in this log:')
        for i, sname in enumerate(srcs, 1):
            print(f'  {i:>4}  {sname}')
        hr()
        while True:
            choice = input('  Select source number(s), e.g. 1,2 (ENTER = all): ').strip()
            if not choice:
                break
            try:
                pick = sorted(set(int(x) for x in choice.replace(' ', ',').split(',') if x))
            except ValueError:
                pick = []
            if pick and all(1 <= n <= len(srcs) for n in pick):
                source = [srcs[n - 1] for n in pick]
                break
            print(f'  Invalid - enter numbers 1..{len(srcs)} separated by comma, or ENTER')
    if source and srcs:
        bad = [x for x in source if x not in srcs]
        if bad:
            die('unknown source "' + bad[0] + '" (available: ' + ', '.join(srcs) + ')')
    if srcs and set(source) == set(srcs):
        source = []                    # all sources selected = no filter

    # source switch in the HTML report: one extra dataset per effective source
    sw_srcs = []
    if not args.no_source_switch:
        _eff = source if source else (srcs if srcs else list_sources(filename))
        if len(_eff) > 1:
            sw_srcs = list(_eff)

    # ── output paths (always auto-generated) ──
    base      = log_base(filename)
    html_path = args.html_out if args.html_out else base + '_report.html'
    txt_path  = base + '_report.txt'

    # ── banner (printed directly, not captured) ──
    print()
    hr('═')
    header_line(f'epinga.py  v{VERSION}  –  eping logfile analyser  –  www.jeitler.cc', '═')
    hr('═')
    print(f'  File : {filename}  ({fmt_bytes(file_size)})')
    if filter_hosts:
        print(f'  Hosts: {", ".join(sorted(filter_hosts))}')
    if source:
        print(f'  Source: {", ".join(source)}')
    if ts_start or ts_end:
        print(f'  Range: {ts_start or "start"} → {ts_end or "end"}')
    print()

    # ── stream & analyse ──
    if args.progress_file:
        _PROG.update(file=args.progress_file, passes=1 + len(sw_srcs), t0=time.time(),
                     phase='analysing all sources' if sw_srcs else 'analysing')
    print('  Analysing…')
    hosts, host_order, rows_read, comments, infos = analyse(
        filename,
        filter_hosts=filter_hosts,
        ts_start=ts_start,
        ts_end=ts_end,
        quiet=args.quiet,
        source=source or None,
    )
    print(f'  {rows_read:,} rows processed  │  {len(hosts)} host(s) found\n')

    if not hosts:
        die('No matching data found.')

    # ── start capturing output for text file ──
    _buf        = io.StringIO()
    _real_out   = sys.stdout
    sys.stdout  = _Tee(_real_out, _buf)
    try:
        _print_report_body(args, hosts, host_order, comments, infos)
    finally:
        sys.stdout = _real_out

    # ── save text report ──
    try:
        with open(txt_path, 'w', encoding='utf-8') as fh:
            fh.write(strip_ansi(_buf.getvalue()))
    except OSError as e:
        die('cannot write ' + txt_path + ': ' + str(e))

    # ── save HTML report ──
    report_data = build_report_data(hosts, host_order, filename, rows_read, base, comments, infos, ', '.join(source))
    variants = []
    for _k, _s in enumerate(sw_srcs):
        print(f'  Analysing source {_s}…')
        _PROG['pass'] = 2 + _k
        _PROG['phase'] = f'analysing source {_s} ({_k + 1}/{len(sw_srcs)})'
        _h, _o, _r, _c, _i = analyse(filename, filter_hosts=filter_hosts, ts_start=ts_start,
                                     ts_end=ts_end, quiet=args.quiet, source=[_s])
        if _h:
            _d = build_report_data(_h, _o, filename, _r, base, None, None, _s)
            variants.append({k: _d[k] for k in ('source', 'rows_read', 'global_start', 'global_end', 'hosts')})
    if variants:
        report_data['variants'] = variants
    _PROG['pass'] = _PROG['passes']
    prog_write(1, 1, 'writing report', force=True)
    try:
        generate_html(report_data, html_path)
    except OSError as e:
        die('cannot write ' + html_path + ': ' + str(e))

    # ── version check ──
    if not args.no_version_check:
        url    = 'https://raw.githubusercontent.com/ewaldj/eping/refs/heads/main/eversions'
        remote = check_version_online(url, 'epinga.py')
        if remote and version_tuple(remote) > version_tuple(VERSION):
            print(col(f'  !! Update available (v{remote}) – https://www.jeitler.cc !!', CRED))
        else:
            print(f'  THX for using epinga.py v{VERSION}  –  www.jeitler.cc')
    else:
        print(f'  THX for using epinga.py v{VERSION}  –  www.jeitler.cc')

    print()
    print(col(f'  Text saved → {txt_path}', CCYAN))
    print(col(f'  HTML saved → {html_path}', CCYAN))

    # ── open HTML ──
    if not args.no_open:
        open_report(html_path, args.open_browser)
    print()


def open_report(html_path, auto_open):
    """Open the report in the default browser (open/xdg-open) - automatically with
    --open, otherwise after an Enter/Esc prompt. Silently skipped without a TTY."""
    import subprocess, platform, shutil
    open_cmd = 'open' if platform.system() == 'Darwin' else 'xdg-open'
    if shutil.which(open_cmd) is None:
        return
    if not auto_open:
        if not sys.stdin.isatty():
            return
        if not getch_prompt(html_path):
            return
    try:
        subprocess.Popen([open_cmd, html_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as e:
        print(col(f'  could not open browser: {e}', CORANGE))


def _print_report_body(args, hosts, host_order, comments, infos):
    """Everything that goes to the terminal AND into the .txt report."""

    # ── info (settings snapshot/change timeline from eping.py's '#INFO#' rows -
    # shown first, above COMMENTS - like the HTML report's Info section, placed
    # above its Comments section) ──
    hr('═')
    header_line(f'INFO ({len(infos)})', '═')
    hr('═')
    print()
    if infos:
        for i in infos:
            ts_str = i['ts'].strftime(TS_FMT) if i['ts'] else '?'
            print(f'  {ts_str}  {col(i["text"], CCYAN)}')
    else:
        print(f'  {col("No info logged.", CDIM)}')
    print()

    # ── comments (global timeline, shown once before the per-host detail - like
    # the HTML report's Comments section, placed above its Host List) ──
    hr('═')
    header_line(f'COMMENTS ({len(comments)})', '═')
    hr('═')
    print()
    if comments:
        for c in comments:
            ts_str = c['ts'].strftime(TS_FMT) if c['ts'] else '?'
            print(f'  {ts_str}  {col(c["text"], CORANGE)}')
    else:
        print(f'  {col("No comments logged.", CDIM)}')
    print()

    # ── per-host detail ──
    if not args.no_detail:
        hr('═')
        header_line('PER-HOST DETAIL', '═')
        hr('═')
        print()
        for h in host_order:
            print_host(h, hosts[h], show_changes=not args.no_changes, comments=comments)

    # ── summary ──
    print_summary(hosts, host_order, sort_by=args.sort)


if __name__ == '__main__':
    main()
