eping - portable Windows folder (web GUI only), launcher version in the title bar

Start
  Double-click eping.exe. A small window opens (no console window); eping runs in the
  background and the web GUI opens in the browser (http://127.0.0.1:8080).

Window
  Status line, "Web port" field and the buttons
  Start / Stop / Restart     eping is asked to exit cleanly first, then ended
  Web port field             1-65535, read from the hosts file (line
                             "opt: -port 9000" in eping-hosts.txt or the -f file),
                             default 8080; a changed value is written back there
                             (not for .csv hosts files) when you press Start / Restart.
                             If the port is already in use, a message
                             asks for another port; eping is not started.
  Open web GUI               opens the browser (also automatic after the start, as soon as
                             eping answers)
  Console log                eping-console.log (output of the last start, errors)
  Update                     checks eversions on GitHub at start and every 6 hours; the
                             Update button appears if eping.py / epinga.py are newer
                             (replaced, no backup files) or if "eping-windows" is newer
                             (full update of all files, eping.exe restarts itself)
  Exit (or close the window) stops eping and quits

Contents
  eping.exe       launcher window (built with Go, no dependencies)
  eping.py        monitor (web GUI mode; no curses on Windows)
  epinga.py       log analyser / HTML report
  fping.exe       fping 4.2 for Windows (https://github.com/badafans/fping-windows)
  cygwin1.dll     Cygwin runtime required by fping.exe
  python\         put the Python "embeddable package" (Windows x86-64, 3.8 or newer,
                  https://www.python.org/downloads/windows/) here, unpacked so that
                  python\python.exe exists. Without it, python.exe from PATH is used.

Options
  Extra eping options: one line in eping-args.txt (optional), e.g.
      -f hosts.txt -ph -w 2
  or as arguments of eping.exe. The web port (and -bind) come from, in this order:
  command line / eping-args.txt, then the "opt:" lines of the hosts file, then the
  defaults (-port 8080, -bind 127.0.0.1).
  Hosts files, logs and reports are stored in this folder.

Notes
  - The web GUI listens on 127.0.0.1 only; add "-bind 0.0.0.0" to eping-args.txt to
    reach it from the network.
  - -wv / -wvc and the terminal (curses) mode are not available on Windows.
  - If fping.exe reports no replies, check the Windows firewall (ICMP echo) and try
    once with eping.exe started as Administrator.
  - Log file names use '-' instead of ':' in the time stamp.
