eping - portable Windows folder (web GUI only)

Start
  Double-click eping.exe. A small window opens (no console window); eping runs in the
  background and the web GUI opens in the browser (http://127.0.0.1:8080).

Window
  Status line, "Web port" field and the buttons
  Start / Stop / Restart     eping is asked to exit cleanly first, then ended
  Web port field             1-65535, applied with Start / Restart and remembered in
                             eping-port.txt. If the port is already in use, a message
                             asks for another port; eping is not started.
  Open web GUI               opens the browser
  Console log                eping-console.log (output of the last start, errors)
  Exit (or close the window) stops eping and quits

Contents
  eping.exe       launcher window (built with Go, no dependencies)
  eping.py        monitor (web GUI mode; no curses on Windows)
  epinga.py       log analyser / HTML report
  fping.exe       fping 4.2 for Windows (https://github.com/badafans/fping-windows)
  cygwin1.dll     Cygwin runtime required by fping.exe
  python\         put the Python "embeddable package" (Windows x86-64, 3.8 or newer,
                  https://www.python.org/downloads/windows/) here, unpacked so that
                  python\python.exe exists. Without it, python.exe from PATH is used.

Options
  Extra eping options: one line in eping-args.txt (optional), e.g.
      -f hosts.txt -ph -w 2
  or as arguments of eping.exe. Order: defaults (-web -bind 127.0.0.1 -port 8080),
  eping-args.txt, eping-port.txt, command line - the last one wins.
  Hosts files, logs and reports are stored in this folder.

Notes
  - The web GUI listens on 127.0.0.1 only; add "-bind 0.0.0.0" to eping-args.txt to
    reach it from the network.
  - -wv / -wvc and the terminal (curses) mode are not available on Windows.
  - If fping.exe reports no replies, check the Windows firewall (ICMP echo) and try
    once with eping.exe started as Administrator.
  - Log file names use '-' instead of ':' in the time stamp.
